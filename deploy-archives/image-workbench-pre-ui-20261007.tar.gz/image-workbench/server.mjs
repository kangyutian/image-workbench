import { createServer } from "node:http";
import { copyFileSync, createReadStream, existsSync, mkdirSync, readFileSync, renameSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { extname, join, normalize, resolve } from "node:path";
import ffmpegPath from "ffmpeg-static";
import ffprobePackage from "ffprobe-static";
import { recoveryAction, TaskScheduler } from "./server/taskScheduler.mjs";
import { accountIdForUsername, ensureAccountIds, migrateTaskAccountId, resolveSessionUser } from "./server/accountIdentity.mjs";
import {
  claimStagedUploadReferences,
  cleanupStagedImageFiles,
  cleanupStagedImages,
  fileForStagedMedia,
  publicTask,
  purgeExpiredStagedUploads,
  stageImagesLocally,
  uploadImagesInParallel,
  validateReferenceImageCount,
  validateWaveSpeedImageSize,
  publicProductSuite,
} from "./server/imageUploads.mjs";
import { TaskStore } from "./server/taskStore.mjs";
import { clientVideoModels, validateVideoInput, videoModelInfo, videoPayloadFor } from "./server/videoModels.mjs";
import { envKeyForModelRequest, grokImageModelInfo, grokPayloadFor, isGrokImageRequest, normalizeGrokImageInput, validateGrokImageInput } from "./server/grokModels.mjs";
import { envKeyForImage2Model, image2EndpointFor } from "./server/image2Models.mjs";
import { isKlingImageRequest, klingImageModelInfo, klingImagePayloadFor, normalizeKlingImageInput, requiresDedicatedKlingImageKey, validateKlingImageInput } from "./server/klingImageModels.mjs";
import { cutoutEndpointFor, cutoutEnvKey, cutoutPayloadFor, isCutoutRequest, normalizeCutoutInput, validateCutoutInput } from "./server/cutoutModels.mjs";
import { UsageLedger } from "./server/usageLedger.mjs";
import { UsageSynchronizer } from "./server/usageSynchronizer.mjs";
import { normalizeUsageRange, summarizeUsage } from "./server/usageStats.mjs";
import { usageResponse } from "./server/usageApi.mjs";
import { mergePredictionIds, mergeResultUrls, predictionIdsFromResponse, reconcileRecoveryResults, recoveryPredictionIds } from "./server/predictionResults.mjs";
import { PRODUCT_SUITE_MAX_PRODUCT_IMAGES, PRODUCT_SUITE_MODELS, PRODUCT_SUITE_SLOTS, buildProductSuitePrompts, normalizeProductSuiteInput, productSuiteGenerationPlan, productSuiteGenerationPrompt, productSuiteImageModel, productSuiteReferenceImages, validateProductSuiteInput } from "./server/productSuiteModels.mjs";
import { analyzeModelReferenceImage } from "./server/modelReferenceAnalysis.mjs";
import { composeSubjectOnFixedBackground, imageBufferDataUrl, prepareComposedImageForUpload } from "./server/imageComposition.mjs";
import { canRecoverProductSuiteBackground, cutoutResultUrlForSuite } from "./server/productSuiteRecovery.mjs";
import { ProductSuiteStore } from "./server/productSuiteStore.mjs";
import { createZipArchive } from "./server/productSuiteArchive.mjs";
import { fetchWithRetry, isTransientFetchError } from "./server/wavespeedTransport.mjs";
import { aspectRatiosFor } from "./server/imageAspectRatios.mjs";
import { authenticateMcpRequest, mcpConfigFromEnv, usersWithMcpService } from "./server/mcpAuth.mjs";
import { handleMcpHttpRequest } from "./server/mcpHttp.mjs";
import { createMcpServer } from "./server/mcpServer.mjs";
import { createMcpOperations } from "./server/mcpOperations.mjs";
import { McpIdempotencyStore } from "./server/mcpIdempotency.mjs";
import { MCP_MAX_IMAGE_BYTES, McpUploadStore, claimUpload, createUploadTicket, markUploadReady, mediaFromUpload, publicUpload, purgeExpiredMcpUploads, uploadTokenMatches, writeUploadBody } from "./server/mcpUploads.mjs";
import { issueDownloadToken, verifyDownloadToken } from "./server/mcpDownloads.mjs";
import { VideoRemixStore } from "./server/videoRemixStore.mjs";
import { analyzeVideoFrames } from "./server/openaiVideoAnalysis.mjs";
import { extractAnalysisFrames, frameDataUrl, probeVideo } from "./server/videoProbe.mjs";
import { mediaAbsolutePath, receiveVideoUpload, removeVideoRemixDirectory, resolveProjectMediaPath } from "./server/videoRemixUploads.mjs";
import { VIDEO_REMIX_ASPECT_RATIOS, VIDEO_REMIX_IMAGE_MODELS, VIDEO_REMIX_LIMITS, VIDEO_REMIX_VIDEO_MODELS, invalidateShotAfterPromptEdit, normalizeVideoRemixSettings, publicVideoRemixProject, recomputeVideoRemixStatus, validateVideoRemixDraft } from "./shared/videoRemixModels.mjs";
import { allStoryboardShotsApproved, imageRequestForShot, remixTaskMetadata, syncRemixTaskResult, videoRequestForShot } from "./server/videoRemixOrchestrator.mjs";

const port = Number(process.env.PORT || 5173);
const root = resolve("dist");
const wavespeedBaseUrl = "https://api.wavespeed.ai/api/v3";
const maxJsonBytes = 120 * 1024 * 1024;
const maxImportedImageBytes = 30 * 1024 * 1024;
const usersFile = resolve("data", "users.json");
const tasksFile = resolve("data", "tasks.json");
const stagedUploadsFile = resolve("data", "staged-uploads.json");
const mcpUploadsFile = resolve("data", "mcp-uploads.json");
const mcpIdempotencyFile = resolve("data", "mcp-idempotency.json");
const usageLedgerFile = resolve("data", "usage-ledger.json");
const productSuitesFile = resolve("data", "product-suites.json");
const videoRemixesFile = resolve("data", "video-remixes.json");
const stagedImagesRoot = resolve("data", "staged-images");
const mcpUploadsRoot = resolve("data", "mcp-uploads");
const videoRemixMediaRoot = resolve("data", "video-remix-media");
const maxReferenceImages = 10;
const stagedUploadCleanupIntervalMs = 60 * 60 * 1000;
const sessionMaxAgeSeconds = 7 * 24 * 60 * 60;
const predictionRequests = new Map();

loadLocalEnv();
const mcpConfig = mcpConfigFromEnv();
const taskStore = new TaskStore({ file: tasksFile });
const productSuiteStore = new ProductSuiteStore({ file: productSuitesFile });
const videoRemixStore = new VideoRemixStore({ file: videoRemixesFile });
const stagedUploadStore = new TaskStore({ file: stagedUploadsFile });
const mcpUploadStore = new McpUploadStore({ file: mcpUploadsFile });
const mcpIdempotencyStore = new McpIdempotencyStore({ file: mcpIdempotencyFile });
const usageLedger = new UsageLedger({ file: usageLedgerFile });
const taskScheduler = new TaskScheduler({
  maxConcurrent: Number(process.env.WORKBENCH_MAX_CONCURRENT_GENERATIONS || 2),
  run: executeWorkbenchTask,
});
const usageSynchronizer = new UsageSynchronizer({
  ledger: usageLedger,
  keyForEntry: usageEnvKeyForEntry,
  apiKeyForEnvKey: billingApiKeyForEnvKey,
  baseUrl: wavespeedBaseUrl,
});

function cleanupExpiredStagedUploads() {
  try {
    purgeExpiredStagedUploads({ store: stagedUploadStore, root: stagedImagesRoot });
  } catch (error) {
    console.warn("Unable to clean expired staged uploads", error instanceof Error ? error.message : error);
  }
}

function cleanupExpiredMcpUploads() {
  try {
    purgeExpiredMcpUploads({ store: mcpUploadStore, root: mcpUploadsRoot });
  } catch (error) {
    console.warn("Unable to clean expired MCP uploads", error instanceof Error ? error.message : error);
  }
}

cleanupExpiredStagedUploads();
cleanupExpiredMcpUploads();
const stagedUploadCleanupTimer = setInterval(() => {
  cleanupExpiredStagedUploads();
  cleanupExpiredMcpUploads();
}, stagedUploadCleanupIntervalMs);
stagedUploadCleanupTimer.unref();

function usersStore() {
  if (!existsSync(usersFile)) {
    const username = String(process.env.WORKBENCH_ADMIN_USERNAME || "").trim();
    const password = String(process.env.WORKBENCH_ADMIN_PASSWORD || "");
    if (!username || !password) return { users: [] };
    const initial = {
      users: [
        {
          username,
          accountId: randomBytes(16).toString("hex"),
          passwordHash: hashPassword(password),
          role: "admin",
          createdAt: new Date().toISOString(),
          lastLoginAt: null,
        },
      ],
    };
    writeUsersStore(initial);
    return initial;
  }

  try {
    const parsed = JSON.parse(readFileSync(usersFile, "utf8"));
    const normalized = ensureAccountIds(Array.isArray(parsed?.users) ? parsed.users : [], () => randomBytes(16).toString("hex"));
    const store = { users: normalized.users };
    if (normalized.changed) writeUsersStore(store);
    return store;
  } catch {
    return { users: [] };
  }
}

function writeUsersStore(store) {
  mkdirSync(resolve("data"), { recursive: true });
  const temporary = `${usersFile}.tmp`;
  writeFileSync(temporary, `${JSON.stringify(store, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
  renameSync(temporary, usersFile);
}

function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const digest = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${digest}`;
}

function passwordMatches(password, passwordHash) {
  const [salt, expected] = String(passwordHash || "").split(":");
  if (!salt || !expected) return false;
  const actual = scryptSync(password, salt, 64).toString("hex");
  const expectedBuffer = Buffer.from(expected, "hex");
  const actualBuffer = Buffer.from(actual, "hex");
  return expectedBuffer.length === actualBuffer.length && timingSafeEqual(expectedBuffer, actualBuffer);
}

function sessionSecret() {
  return String(process.env.WORKBENCH_SESSION_SECRET || "");
}

function signSession(payload) {
  return createHmac("sha256", sessionSecret()).update(payload).digest("base64url");
}

function sessionForUser(user) {
  if (!sessionSecret()) return null;
  const payload = Buffer.from(
    JSON.stringify({ username: user.username, accountId: user.accountId, role: user.role, exp: Math.floor(Date.now() / 1000) + sessionMaxAgeSeconds }),
  ).toString("base64url");
  return `${payload}.${signSession(payload)}`;
}

function currentUser(req) {
  if (!sessionSecret()) return null;
  const cookies = Object.fromEntries(
    String(req.headers.cookie || "")
      .split(";")
      .map((part) => part.trim().split(/=(.*)/s))
      .filter(([key]) => key),
  );
  const token = cookies.workbench_session;
  if (!token || !token.includes(".")) return null;
  const [payload, signature] = token.split(".");
  const expected = signSession(payload);
  if (signature.length !== expected.length || !timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;
  try {
    const session = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if (!session?.username || !session?.role || Number(session.exp) < Date.now() / 1000) return null;
    const user = resolveSessionUser(session, usersStore().users);
    return user ? { username: user.username, accountId: user.accountId, role: user.role } : null;
  } catch {
    return null;
  }
}

function cookieForSession(token, req) {
  const secure = true;
  return `workbench_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${sessionMaxAgeSeconds}${secure ? "; Secure" : ""}`;
}

function clearSessionCookie(req) {
  const secure = true;
  return `workbench_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure ? "; Secure" : ""}`;
}

function publicUser(user) {
  return { username: user.username, role: user.role, createdAt: user.createdAt, lastLoginAt: user.lastLoginAt || null };
}

function migrateStoredAccountIds() {
  const users = usersStore().users;
  for (const task of taskStore.list()) {
    const migrated = migrateTaskAccountId(task, users);
    if (migrated !== task) taskStore.patch(task.id, { accountId: migrated.accountId });
  }
  usageLedger.migrateAccountIds((username) => accountIdForUsername(users, username));
}

migrateStoredAccountIds();

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".webp": "image/webp",
};

const nanoEndpoints = {
  "nano-banana-2-fast": {
    text: "google/nano-banana-2/text-to-image-fast",
    edit: "google/nano-banana-2/edit-fast",
  },
  "nano-banana-2": {
    text: "google/nano-banana-2/text-to-image",
    edit: "google/nano-banana-2/edit",
  },
  "nano-banana-pro": {
    text: "google/nano-banana-pro/text-to-image",
    edit: "google/nano-banana-pro/edit",
  },
  "nano-banana-pro-edit-multi": {
    edit: "google/nano-banana-pro/edit-multi",
  },
};

const commonResolutions = ["1k", "2k", "4k"];
const fastResolutions = ["2k", "4k"];

function isEditMultiRequest(request = {}) {
  return request.provider === "nanobanana" && request.nanoModel === "nano-banana-pro-edit-multi";
}

function allowedAspectRatiosFor(request = {}) {
  if (isGrokImageRequest(request)) return grokImageModelInfo(request.nanoModel)?.aspectRatio || [];
  if (isKlingImageRequest(request)) return klingImageModelInfo(request.nanoModel)?.aspectRatio || [];
  return aspectRatiosFor(request);
}

function allowedResolutionsFor(request = {}) {
  if (isGrokImageRequest(request)) return grokImageModelInfo(request.nanoModel)?.resolution || [];
  if (isKlingImageRequest(request)) return klingImageModelInfo(request.nanoModel)?.resolution || [];
  if (isEditMultiRequest(request)) return [];
  if (request.provider === "nanobanana" && request.nanoModel === "nano-banana-2-fast") return fastResolutions;
  return commonResolutions;
}

function normalizeRequestOptions(request = {}) {
  if (isGrokImageRequest(request)) {
    Object.assign(request, normalizeGrokImageInput(request));
    return request;
  }
  if (isKlingImageRequest(request)) {
    Object.assign(request, normalizeKlingImageInput(request));
    return request;
  }
  const aspects = allowedAspectRatiosFor(request);
  if (!aspects.includes(request.aspectRatio)) request.aspectRatio = aspects[0];

  const resolutions = allowedResolutionsFor(request);
  if (resolutions.length > 0 && !resolutions.includes(request.resolution)) request.resolution = resolutions[0];

  if (isEditMultiRequest(request)) request.count = 2;
  return request;
}

function loadLocalEnv() {
  const envPath = resolve(".env");
  if (!existsSync(envPath)) return;

  for (const line of readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const separator = trimmed.indexOf("=");
    if (separator === -1) continue;
    const key = trimmed.slice(0, separator).trim();
    const value = trimmed.slice(separator + 1).trim().replace(/^['"]|['"]$/g, "");
    if (key && process.env[key] === undefined) process.env[key] = value;
  }
}

function cleanApiKey(rawKey = "") {
  const keyMatch = rawKey.match(/[A-Za-z0-9._-]{20,}/);
  return (keyMatch?.[0] ?? rawKey)
    .replace(/^Bearer\s+/i, "")
    .replace(/[\s\u200B-\u200D\uFEFF]/g, "")
    .trim();
}

function envKeyForRequest(request = {}) {
  if (isCutoutRequest(request)) return cutoutEnvKey();
  if (request.provider === "image2") return envKeyForImage2Model(request.nanoModel);
  return envKeyForModelRequest(request);
}

function usageEnvKeyForEntry(entry = {}) {
  if (entry.credentialScope === "video-remix") return "WAVESPEED_VIDEO_REMIX_API_KEY";
  if (entry.kind === "image" && entry.modelId === "bria-extract-object") return cutoutEnvKey();
  if (entry.kind === "image" && entry.provider === "image2") return envKeyForImage2Model(entry.modelId);
  return envKeyForModelRequest(entry.kind === "video"
    ? { kind: "video", modelId: entry.modelId }
    : { kind: "image", provider: entry.provider, nanoModel: entry.modelId });
}

function billingApiKeyForEnvKey(envKey) {
  return cleanApiKey(process.env[envKey] || process.env.WAVESPEED_API_KEY || "");
}

function wavespeedApiKeyFor(request = {}) {
  if (request.remixProjectId || request.remixStage) {
    const videoKey = cleanApiKey(process.env.WAVESPEED_VIDEO_REMIX_API_KEY || "");
    if (!videoKey) {
      const error = new Error("服务器未配置视频再生服务的 WaveSpeedAI API Key。请设置 WAVESPEED_VIDEO_REMIX_API_KEY。");
      error.statusCode = 500;
      throw error;
    }
    return { apiKey: videoKey, envKey: "WAVESPEED_VIDEO_REMIX_API_KEY" };
  }
  const envKey = envKeyForRequest(request);
  const modelKey = cleanApiKey(process.env[envKey] || "");
  const fallbackKey = cleanApiKey(process.env.WAVESPEED_API_KEY || "");
  if (requiresDedicatedKlingImageKey(request) && !modelKey) {
    const error = new Error(`服务器未配置该 Kling 图片模型的 WaveSpeedAI API Key。请设置 ${envKey}。`);
    error.statusCode = 500;
    throw error;
  }
  return {
    apiKey: modelKey || fallbackKey,
    envKey,
  };
}

function sendText(res, status, body, headers = {}) {
  res.writeHead(status, {
    "content-type": "text/plain; charset=utf-8",
    ...headers,
  });
  res.end(body);
}

function sendJson(res, status, body, headers = {}) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    ...headers,
  });
  res.end(JSON.stringify(body));
}

function readJsonBody(req) {
  return new Promise((resolveBody, reject) => {
    const chunks = [];
    let total = 0;
    req.on("data", (chunk) => {
      total += chunk.length;
      if (total > maxJsonBytes) {
        reject(Object.assign(new Error("Request body is too large."), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      try {
        const raw = Buffer.concat(chunks).toString("utf8");
        resolveBody(raw ? JSON.parse(raw) : {});
      } catch (error) {
        reject(Object.assign(error, { statusCode: 400 }));
      }
    });
    req.on("error", reject);
  });
}

function fileNameFromImageUrl(rawUrl, mimeType) {
  try {
    const parsed = new URL(rawUrl);
    const fromPath = parsed.pathname.split("/").filter(Boolean).pop() || "";
    const cleanName = decodeURIComponent(fromPath).replace(/[^\w.-]+/g, "-").replace(/^-+|-+$/g, "");
    if (cleanName) return cleanName.slice(0, 120);
  } catch {
    // Fall through to the MIME-based default.
  }

  const extensionByMime = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
  };
  return `imported-clothing.${extensionByMime[mimeType] || "png"}`;
}

async function handleImportImage(req, res) {
  try {
    const { url } = await readJsonBody(req);
    if (typeof url !== "string" || !/^https?:\/\//i.test(url.trim())) {
      sendJson(res, 400, { message: "请填写可公开访问的 http 或 https 图片链接。" });
      return;
    }

    const targetUrl = url.trim();
    const response = await fetch(targetUrl, {
      method: "GET",
      redirect: "follow",
      headers: {
        "user-agent": "AI-Image-Workbench/1.0",
        accept: "image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8,*/*;q=0.5",
      },
    });

    if (!response.ok) {
      sendJson(res, 502, { message: "图片链接无法读取，请换成本地上传或检查链接是否可公开访问。" });
      return;
    }

    const mimeType = String(response.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    if (!mimeType.startsWith("image/")) {
      sendJson(res, 400, { message: "这个链接返回的不是图片，请换一个图片直链。" });
      return;
    }

    const contentLength = Number(response.headers.get("content-length") || 0);
    if (contentLength > maxImportedImageBytes) {
      sendJson(res, 413, { message: "图片太大，请压缩图片或换成本地上传。" });
      return;
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    if (buffer.length > maxImportedImageBytes) {
      sendJson(res, 413, { message: "图片太大，请压缩图片或换成本地上传。" });
      return;
    }

    sendJson(res, 200, {
      image: {
        id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`,
        fileName: fileNameFromImageUrl(targetUrl, mimeType),
        dataUrl: `data:${mimeType};base64,${buffer.toString("base64")}`,
        mimeType,
        size: buffer.length,
      },
    });
  } catch {
    sendJson(res, 502, { message: "图片链接无法读取，请换成本地上传或检查链接是否可公开访问。" });
  }
}

function dataUrlToFile(image) {
  if (typeof image?.dataUrl !== "string") throw new Error("Invalid image data.");
  const match = image.dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) throw new Error(`图片 ${image.fileName || ""} 不是可上传的 dataURL。`);
  return {
    mimeType: match[1],
    buffer: Buffer.from(match[2], "base64"),
    fileName: image.fileName || "reference.png",
  };
}

async function wavespeedFetch(path, options = {}, request = {}) {
  const { apiKey, envKey } = wavespeedApiKeyFor(request);
  if (!apiKey) {
    const error = new Error(`服务器未配置该模型的 WaveSpeedAI API Key。请设置 ${envKey}，或设置通用 WAVESPEED_API_KEY。`);
    error.statusCode = 500;
    throw error;
  }

  let response;
  try {
    response = await fetchWithRetry(`${wavespeedBaseUrl}${path}`, {
      ...options,
      headers: {
        Authorization: `Bearer ${apiKey}`,
        ...(options.headers || {}),
      },
    }, {
      // A media upload can be repeated safely; task-submission POST requests
      // must not be retried because WaveSpeed may have accepted and billed them.
      retryOnNetworkError: path === "/media/upload/binary",
    });
  } catch (error) {
    if (isTransientFetchError(error)) {
      const transportError = new Error("WaveSpeedAI 上游网络连接暂时中断，请稍后重试。", { cause: error });
      transportError.statusCode = 503;
      transportError.retryable = true;
      throw transportError;
    }
    throw error;
  }

  const text = await response.text();
  let body = {};
  try {
    body = text ? JSON.parse(text) : {};
  } catch {
    body = { message: text };
  }

  if (!response.ok) {
    const message = body?.error || body?.message || `WaveSpeedAI request failed with ${response.status}`;
    const error = new Error(message);
    error.statusCode = response.status;
    throw error;
  }

  return body;
}

async function uploadImage(image, request) {
  if (typeof image?.dataUrl === "string" && /^https?:\/\//i.test(image.dataUrl)) {
    return image.dataUrl;
  }

  const file = dataUrlToFile(image);
  const form = new FormData();
  form.append("file", new Blob([file.buffer], { type: file.mimeType }), file.fileName);

  const body = await wavespeedFetch(
    "/media/upload/binary",
    {
      method: "POST",
      body: form,
    },
    request,
  );

  const url = body?.data?.download_url;
  if (!url) throw new Error("WaveSpeedAI 上传成功，但没有返回 download_url。");
  return url;
}

function endpointFor(request, hasImages) {
  if (isCutoutRequest(request)) return cutoutEndpointFor(request);
  if (isGrokImageRequest(request)) {
    const model = grokImageModelInfo(request.nanoModel);
    if (!model) throw new Error("请选择可用的 Grok 图片模型。");
    return model.endpoint;
  }
  if (isKlingImageRequest(request)) {
    const model = klingImageModelInfo(request.nanoModel);
    if (!model) throw new Error("请选择可用的 Kling 图片模型。");
    return model.endpoint;
  }
  if (request.provider === "image2") {
    return image2EndpointFor(request.nanoModel, hasImages);
  }

  const model = nanoEndpoints[request.nanoModel] || nanoEndpoints["nano-banana-2-fast"];
  if (hasImages) return model.edit;
  if (!model.text) throw new Error("该 Nano 模型只支持图生图/多图编辑，请先上传参考图。");
  return model.text;
}

function payloadFor(request, uploadedImages) {
  if (isCutoutRequest(request)) return cutoutPayloadFor(request, uploadedImages[0]);
  if (isGrokImageRequest(request)) return grokPayloadFor(request, uploadedImages);
  if (isKlingImageRequest(request)) return klingImagePayloadFor(request, uploadedImages);
  const hasImages = uploadedImages.length > 0;
  const isEditMulti = request.provider === "nanobanana" && request.nanoModel === "nano-banana-pro-edit-multi";
  const payload = {
    prompt: request.prompt,
    aspect_ratio: request.aspectRatio,
    output_format: "png",
    enable_sync_mode: false,
    enable_base64_output: false,
  };

  if (!isEditMulti) {
    payload.resolution = request.resolution;
  } else {
    payload.num_images = 2;
  }

  if (request.provider === "image2") {
    payload.quality = request.quality;
  }

  if (hasImages) {
    payload.images = uploadedImages;
  }

  return payload;
}

function outputUrlsFrom(body) {
  const outputs = body?.data?.outputs ?? body?.data?.output ?? body?.outputs ?? [];
  if (Array.isArray(outputs)) {
    return outputs
      .map((item) => {
        if (typeof item === "string") return item;
        if (typeof item?.url === "string") return item.url;
        return "";
      })
      .filter(Boolean);
  }
  if (typeof outputs === "string") return [outputs];
  return [];
}

async function sleep(ms) {
  await new Promise((resolveSleep) => setTimeout(resolveSleep, ms));
}

async function pollPrediction(id, request) {
  let transientFailures = 0;
  for (let attempt = 0; attempt < 420; attempt += 1) {
    let body;
    try {
      body = await wavespeedFetch(`/predictions/${encodeURIComponent(id)}/result`, { method: "GET" }, request);
      transientFailures = 0;
    } catch (error) {
      if (!error?.retryable || transientFailures >= 5) throw error;
      transientFailures += 1;
      await sleep(Math.min(10_000, 2_000 * transientFailures));
      continue;
    }
    const status = String(body?.data?.status || "").toLowerCase();
    const error = body?.data?.error || body?.error;

    if (status === "completed" || status === "succeeded" || status === "success") {
      const urls = outputUrlsFrom(body);
      if (urls.length > 0) return urls;
      throw new Error("WaveSpeedAI 任务完成，但没有返回图片 URL。");
    }

    if (status === "failed" || status === "error" || error) {
      throw new Error(error || "WaveSpeedAI 任务生成失败。");
    }

    await sleep(2000);
  }

  throw new Error("WaveSpeedAI 任务超时，请稍后到平台任务记录中查看结果。");
}

async function submitOnePrediction(request, uploadedImages) {
  const endpoint = endpointFor(request, uploadedImages.length > 0);
  const body = await wavespeedFetch(
    `/${endpoint}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payloadFor(request, uploadedImages)),
    },
    request,
  );

  const predictionId = String(body?.data?.id || "");
  const immediate = outputUrlsFrom(body);
  if (immediate.length > 0) {
    if (predictionId) predictionRequests.set(predictionId, { provider: request.provider, nanoModel: request.nanoModel });
    return { id: predictionId || null, images: immediate, completed: true };
  }

  const id = body?.data?.id;
  if (!id) throw new Error("WaveSpeedAI 没有返回任务 ID。");
  predictionRequests.set(String(id), { provider: request.provider, nanoModel: request.nanoModel });
  return { id: String(id), completed: false };
}

async function handleGenerate(req, res) {
  try {
    const request = await readJsonBody(req);
    if (!request?.prompt?.trim()) {
      sendJson(res, 400, { message: "请先输入提示词。" });
      return;
    }
    normalizeRequestOptions(request);

    const images = Array.isArray(request.images) ? request.images : [];
    const uploadedImages = await uploadImagesInParallel(images, (image) => uploadImage(image, request));

    const count = Math.max(1, Math.min(8, Number(request.count) || 1));
    const batches = [];
    const submits = request.provider === "nanobanana" && request.nanoModel === "nano-banana-pro-edit-multi" || request.provider === "grok" || isKlingImageRequest(request) ? 1 : count;
    for (let index = 0; index < submits; index += 1) {
      batches.push(await submitOnePrediction(request, uploadedImages));
    }

    sendJson(res, 200, {
      images: batches.flatMap((batch) => (batch.images || []).map((url) => ({ url, source: "url" }))),
      predictionIds: batches.flatMap((batch) => (batch.id ? [batch.id] : [])),
    });
  } catch (error) {
    const status = Number(error?.statusCode || 502);
    const message = error instanceof Error ? error.message : "WaveSpeedAI proxy failed.";
    sendJson(res, status, { message });
  }
}

async function handlePredictionResult(req, res) {
  try {
    const match = req.url.match(/^\/wavespeed\/predictions\/([^/]+)\/result/);
    if (!match) {
      sendJson(res, 404, { message: "Prediction endpoint not found." });
      return;
    }
    const id = decodeURIComponent(match[1]);
    const storedRequest = predictionRequests.get(id);
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const request = storedRequest || {
      provider: url.searchParams.get("provider") || undefined,
      nanoModel: url.searchParams.get("nanoModel") || undefined,
    };
    const body = await wavespeedFetch(`/predictions/${encodeURIComponent(id)}/result`, { method: "GET" }, request);
    sendJson(res, 200, body);
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 502), {
      message: error instanceof Error ? error.message : "WaveSpeedAI prediction lookup failed.",
    });
  }
}

function taskId() {
  return `${Date.now().toString(36)}-${randomBytes(6).toString("hex")}`;
}

function videoRemixOwnerMatches(project, owner) {
  return Boolean(project && (project.accountId ? project.accountId === owner.accountId : project.owner === owner.username));
}

function videoRemixMediaUrl(projectId, mediaId) {
  return `/workbench/video-remixes/${encodeURIComponent(projectId)}/media/${encodeURIComponent(mediaId)}`;
}

function publicVideoRemixResult(project) {
  const result = publicVideoRemixProject(project);
  if (result.sourceVideo?.mediaId) result.sourceVideo.previewUrl = videoRemixMediaUrl(project.id, result.sourceVideo.mediaId);
  if (Array.isArray(result.frames)) result.frames = result.frames.map((frame) => ({ ...frame, previewUrl: videoRemixMediaUrl(project.id, frame.mediaId) }));
  if (Array.isArray(result.productImages)) result.productImages = result.productImages.map((image) => ({ ...image, previewUrl: videoRemixMediaUrl(project.id, image.mediaId) }));
  if (Array.isArray(result.shots)) result.shots = result.shots.map((shot) => shot.sourceFrame?.mediaId
    ? { ...shot, sourceFrame: { ...shot.sourceFrame, previewUrl: videoRemixMediaUrl(project.id, shot.sourceFrame.mediaId) } }
    : shot);
  return result;
}

function videoRemixMediaDataUrl(project, media) {
  const absolutePath = mediaAbsolutePath(project.id, media.stagedPath, { root: videoRemixMediaRoot });
  const buffer = readFileSync(absolutePath);
  return `data:${media.mimeType || "image/jpeg"};base64,${buffer.toString("base64")}`;
}

function mediaExtension(mimeType, fileName = "") {
  const known = { "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "video/mp4": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov" };
  return known[mimeType] || extname(fileName) || ".bin";
}

function sourceFrameForShot(frames, shot) {
  const target = (Number(shot.startSeconds) + Number(shot.endSeconds)) / 2;
  return frames.reduce((closest, frame) => Math.abs(frame.timestampSeconds - target) < Math.abs(closest.timestampSeconds - target) ? frame : closest, frames[0]);
}

async function analyzeVideoRemixProject(projectId) {
  const project = videoRemixStore.get(projectId);
  if (!project?.sourceVideo) throw new Error("请先上传源视频。");
  videoRemixStore.patch(projectId, { status: "analyzing", error: "", analysisError: "" });
  try {
    const sourcePath = mediaAbsolutePath(project.id, project.sourceVideo.stagedPath, { root: videoRemixMediaRoot });
    const outputDir = mediaAbsolutePath(project.id, "frames", { root: videoRemixMediaRoot });
    const extracted = await extractAnalysisFrames(sourcePath, { outputDir, durationSeconds: project.sourceVideo.durationSeconds, maxFrames: 12, ffmpegPath });
    const frames = extracted.map((frame) => ({
      mediaId: frame.fileName.replace(/\.jpg$/i, ""),
      fileName: frame.fileName,
      mimeType: frame.mimeType,
      size: statSync(frame.absolutePath).size,
      stagedPath: `frames/${frame.fileName}`,
      timestampSeconds: frame.timestampSeconds,
    }));
    videoRemixStore.patch(projectId, { frames });
    const analysis = await analyzeVideoFrames({
      frames: await Promise.all(extracted.map(async (frame) => ({ timestampSeconds: frame.timestampSeconds, dataUrl: await frameDataUrl(frame.absolutePath) }))),
      durationSeconds: project.sourceVideo.durationSeconds,
      aspectRatio: project.aspectRatio,
    });
    const shots = analysis.shots.map((shot) => ({ ...shot, sourceFrame: sourceFrameForShot(frames, shot) }));
    const updated = videoRemixStore.patch(projectId, { title: analysis.title, overallScript: analysis.overallScript, shots, status: "script_review", analysisCompletedAt: new Date().toISOString(), error: "", analysisError: "" });
    return updated;
  } catch (error) {
    const message = error instanceof Error ? error.message : "视频分析失败，请重试。";
    videoRemixStore.patch(projectId, { status: "error", error: message, analysisError: message });
    throw error;
  }
}

function createVideoRemixProject(input, owner) {
  const ownerInfo = ownerIdentity(owner);
  if (!VIDEO_REMIX_ASPECT_RATIOS.includes(input?.aspectRatio)) throw Object.assign(new Error("请选择视频输出画面比例。"), { statusCode: 400 });
  const settings = normalizeVideoRemixSettings(input);
  const id = taskId();
  return videoRemixStore.create({
    id,
    owner: ownerInfo.username,
    accountId: ownerInfo.accountId,
    title: String(input?.title || "视频再生项目").trim().slice(0, 160),
    ...settings,
    status: "draft",
    sourceVideo: null,
    frames: [],
    productImages: [],
    overallScript: "",
    shots: [],
    scriptConfirmedAt: null,
    analysisCompletedAt: null,
    error: "",
  });
}

async function queueVideoRemixStoryboardShot(project, shot, owner) {
  const references = [shot.sourceFrame, ...(project.productImages || [])].filter(Boolean).map((media) => ({
    id: media.mediaId,
    fileName: media.fileName,
    mimeType: media.mimeType,
    dataUrl: videoRemixMediaDataUrl(project, media),
  }));
  const request = imageRequestForShot(project, shot, references);
  const task = await createWorkbenchTask({ ...request, ...remixTaskMetadata(project.id, shot.id, "storyboard") }, owner);
  videoRemixStore.patchShot(project.id, shot.id, { imageStatus: "queued", imageTaskId: task.id, imageResultUrl: "", imageError: "", imageApprovedAt: null, videoStatus: "idle", videoTaskId: "", videoResultUrl: "", videoError: "" });
  taskScheduler.enqueue(task);
  return task;
}

async function queueVideoRemixVideoShot(project, shot, owner) {
  const request = videoRequestForShot(project, shot);
  const task = await createWorkbenchTask({ ...request, ...remixTaskMetadata(project.id, shot.id, "video") }, owner);
  videoRemixStore.patchShot(project.id, shot.id, { videoStatus: "queued", videoTaskId: task.id, videoResultUrl: "", videoError: "" });
  taskScheduler.enqueue(task);
  return task;
}

function syncVideoRemixChildTask(taskId) {
  const task = taskStore.get(taskId);
  if (!task || !task.remixProjectId || !["done", "error"].includes(task.status)) return;
  syncRemixTaskResult({ projectStore: videoRemixStore, task });
}

function suiteTaskId(suiteId) {
  return `suite-${suiteId}`;
}

function suiteOwnerMatches(suite, owner) {
  return Boolean(suite && (suite.accountId ? suite.accountId === owner.accountId : suite.owner === owner.username));
}

function suiteStatusForItems(items) {
  if (items.every((item) => item.status === "done")) return "done";
  if (items.some((item) => item.status === "running")) return "running";
  if (items.some((item) => item.status === "done" || item.status === "error")) return "partial";
  return "queued";
}

function createProductSuiteTask(input, owner, { uploadStore = stagedUploadStore } = {}) {
  const ownerInfo = ownerIdentity(owner);
  const modelReferenceImage = input?.modelReferenceImage || null;
  const normalized = normalizeProductSuiteInput({ ...input, ...(modelReferenceImage ? { hasModelReference: true } : {}) });
  const sourceImages = Array.isArray(input.images) ? input.images : [];
  const backgroundImages = Array.isArray(input.backgroundImages) ? input.backgroundImages : [];
  const errors = validateProductSuiteInput({ ...normalized, backgroundImages, modelReferenceImage }, sourceImages);
  if (errors.length) throw Object.assign(new Error(errors[0]), { statusCode: 400 });
  const id = taskId();
  const allImages = [...sourceImages, ...backgroundImages, ...(modelReferenceImage ? [modelReferenceImage] : [])];
  const uploadReferences = allImages.filter((image) => image?.stagedUploadId);
  const claimedByUploadId = new Map();
  if (uploadReferences.length) {
    for (const image of uploadReferences) {
      const claimed = claimStagedUploadReferences([image], { owner: ownerInfo.username, accountId: ownerInfo.accountId, taskId: id, store: uploadStore })[0];
      claimedByUploadId.set(image.stagedUploadId, claimed);
    }
  }
  const localImages = allImages.filter((image) => !image?.stagedUploadId);
  const locallyStaged = localImages.length ? stageImagesLocally(localImages, { taskId: id, root: stagedImagesRoot, maxBytes: maxImportedImageBytes }) : [];
  let localIndex = 0;
  const staged = allImages.map((image) => image?.stagedUploadId ? claimedByUploadId.get(image.stagedUploadId) : locallyStaged[localIndex++]);
  const prompts = buildProductSuitePrompts(normalized);
  const { backgroundImages: _backgroundImages, ...suiteInput } = normalized;
  const backgroundIndex = sourceImages.length;
  const modelReferenceIndex = sourceImages.length + backgroundImages.length;
  const suite = productSuiteStore.create({
    id,
    owner: ownerInfo.username,
    accountId: ownerInfo.accountId,
    status: "queued",
    input: { ...suiteInput, prompts },
    sourceImages: staged.slice(0, sourceImages.length),
    sourceImage: staged[0],
    backgroundImage: backgroundImages.length ? staged[backgroundIndex] || null : null,
    modelReferenceImage: modelReferenceImage ? staged[modelReferenceIndex] || null : null,
    modelReferenceAnalysis: null,
    modelReferenceAnalysisStatus: modelReferenceImage ? "queued" : "not-requested",
    modelReferenceAnalysisUsage: null,
    productImageUrl: "",
    items: PRODUCT_SUITE_SLOTS.map((slot) => ({ slot: slot.slot, label: slot.label, status: "queued", prompt: prompts[slot.slot], defaultPrompt: prompts[slot.slot], resultUrl: "", error: "" })),
  });
  const task = taskStore.create({ id: suiteTaskId(id), owner: ownerInfo.username, accountId: ownerInfo.accountId, kind: "suite", suiteId: id, status: "queued", results: [], error: "" });
  return { suite, task };
}

function publicSuiteResult(suite) {
  const result = publicProductSuite(suite);
  const cutoutUrl = suite.productImageUrl || cutoutResultUrlForSuite(suite.id, taskStore.list());
  result.recovery = { canRecoverBackground: canRecoverProductSuiteBackground(suite, cutoutUrl) };
  return result;
}

async function resolvePrediction(batch, request) {
  if (batch.images?.length) return batch.images;
  return pollPrediction(batch.id, request);
}

function imageDataUrlForModelReference(media) {
  if (typeof media?.dataUrl === "string" && /^(?:https?:\/\/|data:image\/)/i.test(media.dataUrl)) return media.dataUrl;
  const mcpRecord = media?.stagedUploadId ? mcpUploadStore.get(media.stagedUploadId) : null;
  const file = fileForStagedMedia(media, { root: mcpRecord ? mcpUploadsRoot : stagedImagesRoot });
  return `data:${file.mimeType};base64,${file.buffer.toString("base64")}`;
}

async function downloadImageBuffer(url) {
  const dataUrl = String(url || "");
  const match = dataUrl.match(/^data:[^;]+;base64,(.+)$/);
  if (match) return Buffer.from(match[1], "base64");
  if (!/^https?:\/\//i.test(dataUrl)) throw new Error("图片结果不是可读取的 URL。");
  const response = await fetch(dataUrl, { headers: { accept: "image/*" } });
  if (!response.ok) throw new Error(`无法读取图片结果（${response.status}）。`);
  return Buffer.from(await response.arrayBuffer());
}

async function analyzeSuiteModelReference(suite) {
  const currentSuite = productSuiteStore.get(suite.id);
  if (!currentSuite?.modelReferenceImage) return true;
  if (currentSuite.modelReferenceAnalysis) return true;
  productSuiteStore.patch(currentSuite.id, { modelReferenceAnalysisStatus: "running", error: "" });
  try {
    const imageUrl = imageDataUrlForModelReference(currentSuite.modelReferenceImage);
    const { analysis, usage } = await analyzeModelReferenceImage(imageUrl);
    const updatedSuite = productSuiteStore.get(currentSuite.id);
    const analyzedInput = { ...updatedSuite.input, hasModelReference: true, modelReferenceAnalysis: analysis, prompts: {} };
    const analyzedPrompts = buildProductSuitePrompts(analyzedInput);
    const items = updatedSuite.items.map((item) => {
      if (!PRODUCT_SUITE_SLOTS.some((slot) => slot.slot === item.slot) || item.slot === "product-3d") return item;
      const wasDefault = item.prompt === item.defaultPrompt;
      return { ...item, prompt: wasDefault ? analyzedPrompts[item.slot] : item.prompt, defaultPrompt: analyzedPrompts[item.slot] };
    });
    const prompts = Object.fromEntries(items.map((item) => [item.slot, item.prompt]));
    productSuiteStore.patch(currentSuite.id, {
      modelReferenceAnalysis: analysis,
      modelReferenceAnalysisStatus: "done",
      modelReferenceAnalysisUsage: usage,
      input: { ...analyzedInput, prompts },
      items,
      error: "",
    });
    return true;
  } catch (error) {
    const message = error instanceof Error ? error.message : "模特参考图分析失败。";
    productSuiteStore.patch(currentSuite.id, { modelReferenceAnalysisStatus: "error", error: message });
    for (const slot of ["model-front", "model-angle", "model-back"]) productSuiteStore.patchItem(currentSuite.id, slot, { status: "error", resultUrl: "", error: "模特分析失败，未使用默认人物文案。请重试该画面。" });
    console.error("[product-suite] model reference analysis failed", JSON.stringify({ suiteId: currentSuite.id, stage: "model-analysis", error: message }));
    return false;
  }
}

async function ensureSuiteModelReferenceUrl(suite) {
  const currentSuite = productSuiteStore.get(suite.id);
  if (!currentSuite?.modelReferenceImage) return "";
  if (currentSuite.modelReferenceUrl) return currentSuite.modelReferenceUrl;
  const request = { kind: "image", ...productSuiteImageModel(currentSuite.input.model) };
  const url = await uploadMedia(currentSuite.modelReferenceImage, "image", request);
  productSuiteStore.patch(currentSuite.id, { modelReferenceUrl: url });
  return url;
}

async function composeSuiteResult(slot, suite, rawUrl, backgroundUrl) {
  if (!backgroundUrl) return rawUrl;
  const cutoutRequest = {
    mode: "product-cutout",
    provider: "bria",
    nanoModel: "bria-extract-object",
    prompt: "提取生成画面中的服装或模特主体，输出透明背景，不改变主体外观。",
    backgroundMode: "transparent",
    images: [],
  };
  const cutoutTaskId = taskId();
  const cutoutTask = taskStore.create({
    id: cutoutTaskId,
    owner: suite.owner,
    accountId: suite.accountId,
    kind: "image",
    suiteId: suite.id,
    slot: `${slot.slot}-background-cutout`,
    status: "running",
    input: { ...cutoutRequest, images: [{ id: `${cutoutTaskId}-0`, fileName: `${slot.slot}-generated.png`, dataUrl: rawUrl, mimeType: "image/png" }] },
    results: [],
    error: "",
    predictionId: null,
    predictionIds: [],
  });
  recordUsageTask(cutoutTask);
  try {
    const cutout = await submitOnePrediction(cutoutRequest, [rawUrl]);
    if (cutout.id) {
      taskStore.patch(cutoutTaskId, { predictionId: cutout.id, predictionIds: [cutout.id] });
      recordUsageTask(taskStore.get(cutoutTaskId));
    }
    const [subjectUrl] = await resolvePrediction(cutout, cutoutRequest);
    const completed = taskStore.patch(cutoutTaskId, { status: "done", results: [{ url: subjectUrl }], error: "" });
    recordUsageTask(completed, true);

    const [backgroundBuffer, subjectBuffer] = await Promise.all([downloadImageBuffer(backgroundUrl), downloadImageBuffer(subjectUrl)]);
    const composed = await composeSubjectOnFixedBackground(backgroundBuffer, subjectBuffer);
    const uploadImageResult = await prepareComposedImageForUpload(composed);
    const uploadRequest = { kind: "image", ...productSuiteImageModel(suite.input.model) };
    return uploadMedia({ fileName: `${slot.slot}.${uploadImageResult.mimeType === "image/jpeg" ? "jpg" : "png"}`, mimeType: uploadImageResult.mimeType, dataUrl: imageBufferDataUrl(uploadImageResult.buffer, uploadImageResult.mimeType) }, "image", uploadRequest);
  } catch (error) {
    const failed = taskStore.patch(cutoutTaskId, { status: "error", error: error instanceof Error ? error.message : "主体抠图或背景合成失败。" });
    recordUsageTask(failed, true);
    throw error;
  }
}

async function runSuiteImage(slot, suite, productUrl, backgroundUrl, frontImageUrl = "", modelReferenceUrl = "", productReferenceUrls = []) {
  productSuiteStore.patchItem(suite.id, slot.slot, { status: "running", error: "" });
  const imageModel = productSuiteImageModel(suite.input.model);
  const suiteInput = {
    ...suite.input,
    hasModelReference: Boolean(suite.modelReferenceAnalysis || suite.modelReferenceImage || suite.input.hasModelReference),
    ...(suite.modelReferenceAnalysis ? { modelReferenceAnalysis: suite.modelReferenceAnalysis } : {}),
  };
  const request = {
    kind: "image",
    provider: imageModel.provider,
    nanoModel: imageModel.nanoModel,
    prompt: productSuiteGenerationPrompt(slot.slot, suiteInput, suite.items.find((item) => item.slot === slot.slot)?.prompt || ""),
    images: [],
    aspectRatio: "4:5",
    count: 1,
    resolution: "2k",
    quality: "high",
  };
  const childId = taskId();
  const referenceImages = productSuiteReferenceImages(slot.slot, productUrl, backgroundUrl, frontImageUrl, modelReferenceUrl, productReferenceUrls);
  const references = referenceImages.map(({ url }) => url);
  const child = taskStore.create({ id: childId, owner: suite.owner, accountId: suite.accountId, kind: "image", suiteId: suite.id, slot: slot.slot, status: "running", input: { ...request, images: referenceImages.map(({ url, fileName }, index) => ({ id: `${childId}-${index}`, fileName, dataUrl: url, mimeType: "image/png" })) }, results: [], error: "", predictionId: null, predictionIds: [] });
  recordUsageTask(child);
  try {
    const batch = await submitOnePrediction(request, references);
    if (batch.id) {
      taskStore.patch(childId, { predictionId: batch.id, predictionIds: [batch.id] });
      recordUsageTask(taskStore.get(childId));
    }
    const urls = await resolvePrediction(batch, request);
    const done = taskStore.patch(childId, { status: "done", results: urls.map((url) => ({ url })), error: "" });
    recordUsageTask(done, true);
  } catch (error) {
    const failed = taskStore.patch(childId, { status: "error", error: error instanceof Error ? error.message : "生成失败。" });
    recordUsageTask(failed, true);
    productSuiteStore.patchItem(suite.id, slot.slot, { status: "error", error: failed.error });
    console.error("[product-suite] image generation failed", JSON.stringify({ suiteId: suite.id, slot: slot.slot, stage: "image-generation", error: failed.error }));
    return "";
  }

  const rawUrl = productSuiteStore.get(suite.id)?.items.find((item) => item.slot === slot.slot)?.resultUrl || "";
  const rawResult = taskStore.get(childId)?.results?.[0]?.url || rawUrl;
  try {
    const resultUrl = rawResult ? await composeSuiteResult(slot, suite, rawResult, backgroundUrl) : "";
    productSuiteStore.patchItem(suite.id, slot.slot, { status: resultUrl ? "done" : "error", resultUrl, error: resultUrl ? "" : "生成没有返回图片结果。" });
    return resultUrl;
  } catch (error) {
    const message = error instanceof Error ? error.message : "主体抠图或背景合成失败。";
    productSuiteStore.patchItem(suite.id, slot.slot, { status: "error", resultUrl: "", error: message });
    console.error("[product-suite] background composition failed", JSON.stringify({ suiteId: suite.id, slot: slot.slot, stage: "background-composition", error: message }));
    return "";
  }
}

async function executeProductSuiteTask(queuedTask) {
  const suiteTask = taskStore.get(queuedTask.id);
  const suite = suiteTask ? productSuiteStore.get(suiteTask.suiteId) : null;
  if (!suite || suite.status === "done") return;
  let stage = "model-analysis";
  try {
    taskStore.patch(suiteTask.id, { status: "running" });
    productSuiteStore.patch(suite.id, { status: "running" });

    const modelAnalysisReady = await analyzeSuiteModelReference(suite);
    const currentBeforeProductReferences = productSuiteStore.get(suite.id) || suite;
    const sourceImages = Array.isArray(currentBeforeProductReferences.sourceImages)
      ? currentBeforeProductReferences.sourceImages.filter(Boolean)
      : [currentBeforeProductReferences.sourceImage].filter(Boolean);
    let productReferenceUrls = Array.isArray(currentBeforeProductReferences.productReferenceUrls)
      ? currentBeforeProductReferences.productReferenceUrls.filter((url) => typeof url === "string" && url)
      : [];
    let productUrl = currentBeforeProductReferences.productImageUrl || "";
    if (productReferenceUrls.length === 0 && sourceImages.length > 0) {
      stage = "product-reference-upload";
      productReferenceUrls = await uploadImagesInParallel(sourceImages, (image) => uploadMedia(image, "image", { kind: "image", ...productSuiteImageModel(currentBeforeProductReferences.input.model) }));
      productSuiteStore.patch(suite.id, { productReferenceUrls });
      if (productUrl) {
        productSuiteStore.patch(suite.id, { sourceImages: null, sourceImage: null });
        cleanupStagedMediaReferences(sourceImages);
      }
    }
    stage = "cutout";
    if (!productUrl) {
      const cutoutSourceUrl = productReferenceUrls[0];
      if (!cutoutSourceUrl) throw new Error("商品参考图上传失败，请重试。");
      const cutoutRequest = { mode: "product-cutout", provider: "bria", nanoModel: "bria-extract-object", prompt: "main product", backgroundMode: "transparent", images: [{ url: cutoutSourceUrl, fileName: "product-reference-1.png", mimeType: "image/png" }] };
      const cutoutTaskId = taskId();
      const cutoutTask = taskStore.create({ id: cutoutTaskId, owner: suite.owner, accountId: suite.accountId, kind: "image", suiteId: suite.id, slot: "cutout", status: "running", input: cutoutRequest, results: [], error: "", predictionId: null, predictionIds: [] });
      recordUsageTask(cutoutTask);
      try {
        const cutout = await submitOnePrediction(cutoutRequest, [cutoutSourceUrl]);
        if (cutout.id) {
          taskStore.patch(cutoutTaskId, { predictionId: cutout.id, predictionIds: [cutout.id] });
          recordUsageTask(taskStore.get(cutoutTaskId));
        }
        [productUrl] = await resolvePrediction(cutout, cutoutRequest);
        const completedCutout = taskStore.patch(cutoutTaskId, { status: "done", results: [{ url: productUrl }], error: "" });
        recordUsageTask(completedCutout, true);
        productSuiteStore.patch(suite.id, { productImageUrl: productUrl, sourceImages: null, sourceImage: null });
        cleanupStagedMediaReferences(sourceImages);
      } catch (error) {
        const failedCutout = taskStore.patch(cutoutTaskId, { status: "error", error: error instanceof Error ? error.message : "抠图失败。" });
        recordUsageTask(failedCutout, true);
        console.error("[product-suite] cutout failed", JSON.stringify({ suiteId: suite.id, stage: "cutout", error: failedCutout.error }));
        throw error;
      }
    }
    stage = "background-upload";
    let backgroundUrl = suite.input.backgroundMode === "custom" && suite.backgroundImage ? suite.backgroundUrl || "" : "";
    if (!backgroundUrl && suite.input.backgroundMode === "custom" && suite.backgroundImage) {
      backgroundUrl = await uploadMedia(suite.backgroundImage, "image", productSuiteImageModel(suite.input.model));
      productSuiteStore.patch(suite.id, { productImageUrl: productUrl, backgroundUrl, backgroundImage: null });
      cleanupStagedMediaReferences([suite.backgroundImage]);
    }
    productSuiteStore.patch(suite.id, { productImageUrl: productUrl, backgroundUrl });

    stage = "model-reference-upload";
    let modelReferenceUrl = "";
    const latestBeforeImages = productSuiteStore.get(suite.id);
    const hasPendingModelImages = latestBeforeImages?.items?.some((item) => PRODUCT_SUITE_SLOTS.some((slot) => slot.slot === item.slot) && item.slot !== "product-3d" && item.status !== "done");
    if (modelAnalysisReady && hasPendingModelImages && latestBeforeImages?.modelReferenceImage) {
      modelReferenceUrl = await ensureSuiteModelReferenceUrl(latestBeforeImages);
    }

    stage = "image-generation";
    const currentSuite = productSuiteStore.get(suite.id);
    const plan = productSuiteGenerationPlan(currentSuite.items, queuedTask.suiteRetrySlot || "");
    const runItem = (item, frontImageUrl = "") => runSuiteImage(PRODUCT_SUITE_SLOTS.find((slot) => slot.slot === item.slot), productSuiteStore.get(suite.id), productUrl, backgroundUrl, frontImageUrl, modelReferenceUrl, productReferenceUrls);
    await Promise.all(plan.independent.map((item) => runItem(item)));

    let frontImageUrl = productSuiteStore.get(suite.id)?.items.find((item) => item.slot === "model-front")?.resultUrl || "";
    if (plan.front && modelAnalysisReady) frontImageUrl = await runItem(plan.front);

    if (plan.identityDependent.length > 0) {
      if (!modelAnalysisReady) {
        for (const item of plan.identityDependent) productSuiteStore.patchItem(suite.id, item.slot, { status: "error", error: "模特分析失败，未使用默认人物文案。请先重试正面图。" });
      } else if (!frontImageUrl) {
        const dependencyError = "正面模特图生成失败，侧面和背面暂不生成。请先重试正面图。";
        for (const item of plan.identityDependent) productSuiteStore.patchItem(suite.id, item.slot, { status: "error", error: dependencyError });
      } else {
        await Promise.all(plan.identityDependent.map((item) => runItem(item, frontImageUrl)));
      }
    }
    const finished = productSuiteStore.get(suite.id);
    const activeSlots = new Set(PRODUCT_SUITE_SLOTS.map(({ slot }) => slot));
    const status = suiteStatusForItems(finished.items.filter((item) => activeSlots.has(item.slot)));
    productSuiteStore.patch(suite.id, {
      status,
      ...(status === "done" ? { productReferenceUrls: [] } : {}),
      ...(status === "done" && finished.modelReferenceImage ? { modelReferenceImage: null, modelReferenceUrl: "" } : {}),
    });
    if (status === "done" && finished.modelReferenceImage) cleanupStagedMediaReferences([finished.modelReferenceImage]);
    taskStore.patch(suiteTask.id, { status: status === "done" ? "done" : "error", error: status === "partial" ? "部分图片生成失败，请重试失败画面。" : "" });
  } catch (error) {
    const message = error instanceof Error ? error.message : "商品套图生成失败。";
    console.error("[product-suite] task failed", JSON.stringify({ suiteId: suite.id, stage, error: message }));
    productSuiteStore.failQueuedItems(suite.id, message);
    productSuiteStore.patch(suite.id, { status: "error", error: message });
    taskStore.patch(suiteTask.id, { status: "error", error: message });
  }
}

function recordUsageTask(task, queueBilling = false) {
  if (!task) return;
  usageLedger.upsertTask(task);
  if (queueBilling) usageSynchronizer.enqueue();
}

function patchTaskAndUsage(id, changes, queueBilling = false) {
  const task = taskStore.patch(id, changes);
  recordUsageTask(task, queueBilling);
  if (task && ["done", "error"].includes(task.status)) syncVideoRemixChildTask(id);
  return task;
}

function ownerIdentity(owner) {
  const username = String(typeof owner === "string" ? owner : owner?.username || "").trim();
  const users = usersStore().users;
  const user = users.find((item) => item.username === username);
  return {
    username,
    accountId: String(typeof owner === "object" && owner?.accountId || user?.accountId || accountIdForUsername(users, username)),
  };
}

const mcpImageModels = [
  { id: "nano-banana-2-fast", provider: "nanobanana", mode: "text-to-image,image-to-image" },
  { id: "nano-banana-2", provider: "nanobanana", mode: "text-to-image,image-to-image" },
  { id: "nano-banana-pro", provider: "nanobanana", mode: "text-to-image,image-to-image" },
  { id: "nano-banana-pro-edit-multi", provider: "nanobanana", mode: "multi-image-edit" },
  { id: "image2", provider: "image2", mode: "text-to-image,image-to-image" },
  { id: "grok-2-image", provider: "grok", mode: "text-to-image" },
  { id: "grok-imagine-image-edit", provider: "grok", mode: "image-to-image" },
  { id: "grok-imagine-image-quality", provider: "grok", mode: "text-to-image" },
  { id: "kling-image-v3-edit", provider: "kling", mode: "image-to-image" },
  { id: "kling-image-o3-edit", provider: "kling", mode: "multi-image-edit" },
  { id: "kling-image-o1", provider: "kling", mode: "image-to-image" },
];

function mcpPublicBaseUrl() {
  return String(process.env.WORKBENCH_PUBLIC_URL || "https://nxtnumber.com").replace(/\/$/, "");
}

function mcpCapabilities() {
  return {
    account: { username: mcpConfig.username, account_id: mcpConfig.accountId },
    limits: { image_max_bytes: MCP_MAX_IMAGE_BYTES - 1, image_limit_label: "小于10MB", video_max_bytes: Number(process.env.WORKBENCH_MAX_VIDEO_UPLOAD_BYTES || 100 * 1024 * 1024) },
    image_models: mcpImageModels,
    video_models: clientVideoModels(),
    cutout: { model: "bria-extract-object", backgrounds: ["transparent", "white"] },
    product_suite: { models: PRODUCT_SUITE_MODELS.map(({ id, label, provider, nanoModel }) => ({ id, label, provider, nano_model: nanoModel })), slots: PRODUCT_SUITE_SLOTS.map(({ slot, label, fileName }) => ({ slot, label, file_name: fileName })), max_product_images: PRODUCT_SUITE_MAX_PRODUCT_IMAGES, aspect_ratio: "4:5", resolution: "2k", model_reference_analysis: { model: "openai/gpt-5.6-sol", selectable_options_locked: true }, hair_colors: ["natural", "black", "dark-brown", "light-brown", "blonde", "copper-red", "silver-gray"] },
  };
}

function mcpResolveMediaRef(ref, { mediaKind, owner }) {
  if (typeof ref?.url === "string" && /^https:\/\//i.test(ref.url)) {
    return { dataUrl: ref.url, url: ref.url, fileName: mediaKind === "video" ? "reference.mp4" : "reference.png", mimeType: mediaKind === "video" ? "video/mp4" : "image/png" };
  }
  const uploadId = String(ref?.media_id || "");
  const record = uploadId ? mcpUploadStore.get(uploadId) : null;
  return mediaFromUpload(record, owner);
}

function mcpTaskOrNotFound(id, owner) {
  const task = taskStore.get(id);
  if (!task || !ownsTask(task, owner)) throw Object.assign(new Error("任务不存在。"), { statusCode: 404 });
  return task;
}

function mcpSuiteOrNotFound(id, owner) {
  const suite = productSuiteStore.get(id);
  if (!suite || !suiteOwnerMatches(suite, owner)) throw Object.assign(new Error("商品套图任务不存在。"), { statusCode: 404 });
  return suite;
}

function mcpDownloadUrl(owner, kind, id) {
  const token = issueDownloadToken(mcpConfig.token, { accountId: owner.accountId, kind, id });
  return `${mcpPublicBaseUrl()}/mcp/downloads/${kind}/${encodeURIComponent(id)}?token=${encodeURIComponent(token)}`;
}

function createMcpOperationsFor(owner) {
  return createMcpOperations({
    owner,
    idempotency: mcpIdempotencyStore,
    capabilities: mcpCapabilities,
    resolveMediaRef: mcpResolveMediaRef,
    createUploadTicket: ({ owner: uploadOwner, ...input }) => {
      const ticket = createUploadTicket({ store: mcpUploadStore, owner: uploadOwner, fileName: input.file_name, mimeType: input.mime_type, size: input.size, mediaKind: input.media_kind });
      return { ...ticket, upload_url: `${mcpPublicBaseUrl()}${ticket.upload_url}` };
    },
    getUpload: ({ uploadId, owner: uploadOwner }) => {
      const record = mcpUploadStore.get(uploadId);
      const result = publicUpload(record, uploadOwner);
      if (!result) throw Object.assign(new Error("上传记录不存在。"), { statusCode: 404 });
      return result;
    },
    createTask: (input, taskOwner) => createWorkbenchTask(input, taskOwner, { uploadStore: mcpUploadStore }),
    enqueue: (task) => taskScheduler.enqueue(task),
    publicTask,
    publicSuite: publicSuiteResult,
    listTasks: ({ owner: taskOwner, kind, status, limit = 100 }) => ({
      tasks: taskStore.list()
        .filter((task) => !task.suiteId && task.kind !== "suite" && ownsTask(task, taskOwner))
        .filter((task) => !kind || task.kind === kind)
        .filter((task) => !status || task.status === status)
        .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
        .slice(0, Math.max(1, Math.min(100, Number(limit) || 100)))
        .map(publicTask),
    }),
    getTask: ({ taskId, owner: taskOwner }) => publicTask(mcpTaskOrNotFound(taskId, taskOwner)),
    listProductSuites: ({ owner: suiteOwner }) => ({ suites: productSuiteStore.forOwner(suiteOwner).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).map(publicSuiteResult) }),
    getProductSuite: ({ suiteId, owner: suiteOwner }) => publicSuiteResult(mcpSuiteOrNotFound(suiteId, suiteOwner)),
    getTaskDownload: ({ taskId, owner: taskOwner }) => {
      const task = mcpTaskOrNotFound(taskId, taskOwner);
      return { task_id: task.id, download_url: mcpDownloadUrl(taskOwner, "task", task.id), expires_in_seconds: 900, urls: (task.results || []).map((result) => result.url).filter(Boolean) };
    },
    getProductSuiteDownload: ({ suiteId, owner: suiteOwner }) => {
      const suite = mcpSuiteOrNotFound(suiteId, suiteOwner);
      return { suite_id: suite.id, download_url: mcpDownloadUrl(suiteOwner, "suite", suite.id), expires_in_seconds: 900 };
    },
    createProductSuite: (input, suiteOwner) => createProductSuiteTask(input, suiteOwner, { uploadStore: mcpUploadStore }),
    retryTask: ({ taskId: targetTaskId, owner: taskOwner }) => {
      const task = mcpTaskOrNotFound(targetTaskId, taskOwner);
      const retry = createTaskAndUsage({ id: taskId(), owner: taskOwner, kind: task.kind, expectedPredictionCount: task.expectedPredictionCount || (task.kind === "video" ? 1 : Math.max(1, Math.min(8, Number(task.input?.count) || 1))), status: "queued", input: task.input, results: [], error: "", predictionId: null, predictionIds: [], retryOf: task.id });
      taskScheduler.enqueue(retry);
      return retry;
    },
    cancelTask: ({ taskId, owner: taskOwner }) => {
      const task = mcpTaskOrNotFound(taskId, taskOwner);
      const status = task.status === "queued" ? "cancelled" : "cancel_requested";
      return patchTaskAndUsage(task.id, { status, cancelledAt: new Date().toISOString() }, true);
    },
    retryProductSuiteSlot: ({ suiteId, slot, owner: suiteOwner }) => {
      const suite = mcpSuiteOrNotFound(suiteId, suiteOwner);
      if (!PRODUCT_SUITE_SLOTS.some((item) => item.slot === slot)) throw Object.assign(new Error("无效的商品套图画面。"), { statusCode: 400 });
      const retrySlots = slot === "model-front" ? ["model-front", "model-angle", "model-back"] : [slot];
      for (const retrySlot of retrySlots) productSuiteStore.patchItem(suiteId, retrySlot, { status: "queued", resultUrl: "", error: "" });
      if (slot === "model-front" && suite.modelReferenceImage) {
        productSuiteStore.patch(suiteId, { modelReferenceAnalysis: null, modelReferenceAnalysisStatus: "queued", modelReferenceAnalysisUsage: null, input: { ...suite.input, modelReferenceAnalysis: null } });
      }
      const task = taskStore.create({ id: taskId(), owner: suiteOwner.username, accountId: suiteOwner.accountId, kind: "suite", suiteId, suiteRetrySlot: slot, status: "queued", results: [], error: "" });
      productSuiteStore.patch(suiteId, { status: "queued" });
      taskScheduler.enqueue(task);
      return { suite: productSuiteStore.get(suiteId), task };
    },
  });
}

function createTaskAndUsage(input) {
  const owner = ownerIdentity(input.owner);
  const task = taskStore.create({ ...input, owner: owner.username, accountId: owner.accountId });
  recordUsageTask(task);
  return task;
}

function publicMediaUrl(media) {
  return typeof media?.dataUrl === "string" && /^https?:\/\//i.test(media.dataUrl) ? media.dataUrl : typeof media?.url === "string" ? media.url : "";
}

function mediaSizeLimit(mediaType) {
  return mediaType === "video" ? Number(process.env.WORKBENCH_MAX_VIDEO_UPLOAD_BYTES || 100 * 1024 * 1024) : maxImportedImageBytes;
}

async function uploadMedia(media, mediaType, request = {}) {
  const url = publicMediaUrl(media);
  if (url) return url;
  const mcpRecord = media?.stagedUploadId ? mcpUploadStore.get(media.stagedUploadId) : null;
  const file = media?.stagedPath
    ? fileForStagedMedia(media, { root: mcpRecord ? mcpUploadsRoot : stagedImagesRoot })
    : dataUrlToFile(media);
  if (mediaType === "video" && !["video/mp4", "video/webm", "video/quicktime"].includes(file.mimeType)) throw new Error("动作参考视频仅支持 MP4、WebM 或 MOV 文件。");
  if (mediaType === "image" && !file.mimeType.startsWith("image/")) throw new Error("请上传图片文件。");
  if (file.buffer.length > mediaSizeLimit(mediaType)) throw Object.assign(new Error(mediaType === "video" ? "视频文件太大，请压缩后再试。" : "图片太大，请压缩后再试。"), { statusCode: 413 });
  if (mediaType === "image") validateWaveSpeedImageSize(file.buffer.length);
  const form = new FormData();
  form.append("file", new Blob([file.buffer], { type: file.mimeType }), file.fileName);
  const body = await wavespeedFetch("/media/upload/binary", { method: "POST", body: form }, request);
  const uploadUrl = body?.data?.download_url;
  if (!uploadUrl) throw new Error("WaveSpeedAI 上传成功，但没有返回 download_url。");
  return uploadUrl;
}

function cleanupStagedMediaReferences(mediaItems = []) {
  const local = [];
  const mcp = [];
  for (const media of mediaItems.filter(Boolean)) {
    if (!media?.stagedPath) continue;
    if (media.stagedUploadId && mcpUploadStore.get(media.stagedUploadId)) mcp.push(media);
    else local.push(media);
  }
  if (local.length) {
    cleanupStagedImageFiles(local, { root: stagedImagesRoot });
    for (const media of local) if (media.stagedUploadId) stagedUploadStore.remove(media.stagedUploadId);
  }
  if (mcp.length) {
    cleanupStagedImageFiles(mcp, { root: mcpUploadsRoot });
    for (const media of mcp) mcpUploadStore.remove(media.stagedUploadId);
  }
}

async function prepareVideoTaskMedia(task, request) {
  const imageInputs = Array.isArray(request.referenceImages) ? request.referenceImages : [];
  const uploadedImages = await uploadImagesInParallel(imageInputs, (image) => uploadMedia(image, "image", request));
  const motionInput = request.motionVideo;
  const motionUrl = motionInput ? await uploadMedia(motionInput, "video", request) : "";
  const prepared = {
    ...request,
    referenceImages: uploadedImages.map((url) => ({ url })),
    ...(motionInput ? { motionVideo: { url: motionUrl } } : {}),
  };
  if (imageInputs.some((image) => image?.stagedPath) || motionInput?.stagedPath) {
    patchTaskAndUsage(task.id, { input: prepared });
    cleanupStagedMediaReferences([...imageInputs, motionInput]);
  }
  return prepared;
}

async function executeWorkbenchTask(queuedTask) {
  if (queuedTask?.kind === "suite") return executeProductSuiteTask(queuedTask);
  const task = taskStore.get(queuedTask.id);
  if (!task || task.status === "cancelled" || task.status === "done") return;
  try {
    patchTaskAndUsage(task.id, { status: "running", error: "" });
    const request = task.input;
    const existingPredictionIds = recoveryPredictionIds(task);
    if (existingPredictionIds.length) {
      const settled = await Promise.allSettled(existingPredictionIds.map((id) => pollPrediction(id, request)));
      const recovery = reconcileRecoveryResults(task.results, settled);
      const urls = recovery.urls;
      const expectedPredictionCount = Number(task.expectedPredictionCount) || 0;
      if (recovery.failedCount > 0 || expectedPredictionCount > existingPredictionIds.length) {
        patchTaskAndUsage(task.id, {
          status: "error",
          results: urls.map((url) => ({ url })),
          error: recovery.failedCount > 0 ? recovery.error : "Task recovery found fewer submitted predictions than expected; retry is required before completion.",
        }, true);
        return;
      }
      patchTaskAndUsage(task.id, { status: task.status === "cancel_requested" ? "cancelled" : "done", results: urls.map((url) => ({ url })), error: "" }, true);
      return;
    }
    if (task.kind === "video") {
      const preparedRequest = await prepareVideoTaskMedia(task, request);
      const model = videoModelInfo(preparedRequest.modelId);
      const body = await wavespeedFetch(`/${model.endpoint}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(videoPayloadFor(preparedRequest)) }, preparedRequest);
      const immediate = outputUrlsFrom(body);
      const [predictionId] = predictionIdsFromResponse(body);
      if (predictionId) predictionRequests.set(predictionId, { provider: preparedRequest.provider, nanoModel: preparedRequest.nanoModel });
      if (immediate.length) {
        const predictionIds = mergePredictionIds(task.predictionIds, predictionId ? [predictionId] : []);
        patchTaskAndUsage(task.id, {
          status: "done",
          results: mergeResultUrls(task.results, immediate).map((url) => ({ url })),
          ...(predictionIds.length ? { predictionId: predictionIds[0], predictionIds } : {}),
          error: "",
        }, true);
        return;
      }
      if (!predictionId) throw new Error("WaveSpeedAI 没有返回任务 ID。");
      const predictionIds = mergePredictionIds(task.predictionIds, [predictionId]);
      patchTaskAndUsage(task.id, { predictionId: predictionIds[0], predictionIds });
      const urls = await pollPrediction(predictionId, preparedRequest);
      patchTaskAndUsage(task.id, { status: "done", results: mergeResultUrls(task.results, urls).map((url) => ({ url })), error: "" }, true);
      return;
    }
    const imageInputs = Array.isArray(request.images) ? request.images : [];
    const images = await uploadImagesInParallel(imageInputs, (image) => uploadMedia(image, "image", request));
    if (imageInputs.some((image) => image?.stagedPath)) {
      const persistedImages = imageInputs.map((image, index) => {
        const { stagedPath, stagedUploadId, ...metadata } = image;
        return { ...metadata, dataUrl: images[index] };
      });
      request.images = persistedImages;
      patchTaskAndUsage(task.id, { input: request });
      cleanupStagedMediaReferences(imageInputs);
    }
    const count = Math.max(1, Math.min(8, Number(request.count) || 1));
    const batches = [];
    const submits = request.provider === "grok" || isKlingImageRequest(request) || isEditMultiRequest(request) ? 1 : count;
    let predictionIds = [...(task.predictionIds || [])];
    for (let index = 0; index < submits; index += 1) {
      const batch = await submitOnePrediction(request, images);
      batches.push(batch);
      if (batch.id) {
        predictionIds = mergePredictionIds(predictionIds, [batch.id]);
        patchTaskAndUsage(task.id, { predictionId: predictionIds[0], predictionIds });
      }
    }
    const urls = batches.flatMap((batch) => batch.images || []);
    const ids = batches.flatMap((batch) => batch.id && !batch.completed ? [batch.id] : []);
    const resolved = (await Promise.all(ids.map((id) => pollPrediction(id, request)))).flat();
    patchTaskAndUsage(task.id, { status: "done", results: mergeResultUrls(task.results, [...urls, ...resolved]).map((url) => ({ url })), error: "" }, true);
  } catch (error) {
    taskStore.patch(task.id, { status: "error", error: error instanceof Error ? error.message : "任务执行失败，请稍后重试。" });
    syncVideoRemixChildTask(task.id);
  }
  recordUsageTask(taskStore.get(task.id), true);
}

async function handleUploadMedia(req, res) {
  try {
    const body = await readJsonBody(req);
    const mediaType = body?.mediaType === "video" ? "video" : "image";
    const request = body?.request && typeof body.request === "object" ? body.request : body?.modelId ? { kind: "video", modelId: body.modelId } : {};
    sendJson(res, 200, { url: await uploadMedia(body?.media, mediaType, request) });
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "媒体上传失败。" });
  }
}

async function handleStageImage(req, res, owner) {
  const uploadId = taskId();
  try {
    const body = await readJsonBody(req);
    const staged = stageImagesLocally([body?.media], {
      taskId: uploadId,
      root: stagedImagesRoot,
      maxBytes: maxImportedImageBytes,
    })[0];
    const image = { ...staged, stagedUploadId: uploadId };
    stagedUploadStore.create({ id: uploadId, owner: owner.username, accountId: owner.accountId, image, claimedBy: null, consumedAt: null });
    sendJson(res, 201, {
      media: {
        id: image.id,
        fileName: image.fileName,
        mimeType: image.mimeType,
        size: image.size,
        stagedUploadId: uploadId,
      },
    });
  } catch (error) {
    cleanupStagedImages(uploadId, { root: stagedImagesRoot });
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "图片暂存失败。" });
  }
}

function videoRemixProjectOrNotFound(id, owner) {
  const project = videoRemixStore.get(id);
  if (!project || !videoRemixOwnerMatches(project, owner)) return null;
  return project;
}

function decodeHeaderFileName(value, fallback) {
  try {
    return decodeURIComponent(String(value || fallback)).replace(/[\\/]/g, "-").slice(0, 160) || fallback;
  } catch {
    return fallback;
  }
}

async function handleVideoRemixCreate(req, res, owner) {
  try {
    const body = await readJsonBody(req);
    const project = createVideoRemixProject(body, owner);
    sendJson(res, 201, { project: publicVideoRemixResult(project) });
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "无法创建视频再生项目。" });
  }
}

function handleVideoRemixList(res, owner) {
  sendJson(res, 200, { projects: videoRemixStore.forOwner(owner).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).map(publicVideoRemixResult) });
}

function handleVideoRemixGet(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/video-remixes\/([^/?]+)$/)?.[1] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  sendJson(res, 200, { project: publicVideoRemixResult(project) });
}

async function handleVideoRemixSourceUpload(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/video-remixes\/([^/]+)\/source-video/)?.[1] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  if (project.sourceVideo) return sendJson(res, 409, { message: "该项目已经上传源视频，如需更换请重新创建项目。" });
  let media;
  try {
    const contentType = String(req.headers["content-type"] || "").split(";")[0].trim().toLowerCase();
    media = await receiveVideoUpload(req, {
      root: videoRemixMediaRoot,
      projectId: id,
      fileName: decodeHeaderFileName(req.headers["x-file-name"], "source-video.mp4"),
      mimeType: contentType,
      size: Number(req.headers["content-length"] || 0) || undefined,
    });
    const absolutePath = mediaAbsolutePath(id, media.stagedPath, { root: videoRemixMediaRoot });
    const metadata = await probeVideo(absolutePath, { ffprobePath: ffprobePackage.path });
    const sourceVideo = { ...media, mediaId: "source-video", ...metadata };
    const updated = videoRemixStore.patch(id, { sourceVideo, status: "uploaded", error: "" });
    sendJson(res, 201, { project: publicVideoRemixResult(updated) });
  } catch (error) {
    if (media?.stagedPath) {
      try { unlinkSync(mediaAbsolutePath(id, media.stagedPath, { root: videoRemixMediaRoot })); } catch { /* best effort cleanup */ }
    }
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "视频上传失败。" });
  }
}

async function handleVideoRemixProductImage(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/video-remixes\/([^/]+)\/product-images/)?.[1] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  const uploadId = taskId();
  let directImage = null;
  try {
    const body = await readJsonBody(req);
    const stagedUploadId = String(body?.stagedUploadId || "");
    const record = stagedUploadId ? stagedUploadStore.get(stagedUploadId) : null;
    if (body?.media) {
      directImage = stageImagesLocally([body.media], { taskId: uploadId, root: stagedImagesRoot, maxBytes: maxImportedImageBytes })[0];
    } else if (!record || record.owner !== owner.username || record.accountId !== owner.accountId || record.claimedBy || !record.image?.stagedPath) {
      throw Object.assign(new Error("产品图片暂存已失效，请重新上传。"), { statusCode: 400 });
    }
    const sourceImage = directImage || record.image;
    if (!sourceImage?.stagedPath) throw Object.assign(new Error("产品图片暂存已失效，请重新上传。"), { statusCode: 400 });
    if ((project.productImages || []).length >= VIDEO_REMIX_LIMITS.maxProductImages) throw Object.assign(new Error("每个项目最多上传 5 张产品参考图。"), { statusCode: 400 });
    if (!String(sourceImage.mimeType || "").startsWith("image/")) throw Object.assign(new Error("产品参考图必须是图片文件。"), { statusCode: 400 });
    const mediaId = `product-${uploadId}`;
    const extension = mediaExtension(sourceImage.mimeType, sourceImage.fileName);
    const stagedPath = `products/${mediaId}${extension}`;
    const targetPath = mediaAbsolutePath(id, stagedPath, { root: videoRemixMediaRoot });
    mkdirSync(resolve(targetPath, ".."), { recursive: true });
    const sourcePath = resolve(stagedImagesRoot, sourceImage.stagedPath);
    copyFileSync(sourcePath, targetPath, { mode: 0o600 });
    const productImage = { mediaId, fileName: sourceImage.fileName || `${mediaId}${extension}`, mimeType: sourceImage.mimeType, size: sourceImage.size, stagedPath, isPrimary: (project.productImages || []).length === 0 };
    if (stagedUploadId) stagedUploadStore.patch(stagedUploadId, { claimedBy: id, claimedAt: new Date().toISOString(), consumedAt: new Date().toISOString() });
    cleanupStagedMediaReferences([sourceImage]);
    const updated = videoRemixStore.patch(id, { productImages: [...(project.productImages || []), productImage] });
    sendJson(res, 201, { project: publicVideoRemixResult(updated), image: publicVideoRemixResult(updated).productImages.at(-1) });
  } catch (error) {
    if (directImage?.stagedPath) cleanupStagedImages(uploadId, { root: stagedImagesRoot });
    console.warn("[video-remix] product image upload failed", JSON.stringify({ projectId: id, stage: "product-image-upload", error: error instanceof Error ? error.message : "unknown" }));
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "产品图片上传失败。" });
  }
}

async function handleVideoRemixScriptPatch(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/video-remixes\/([^/?]+)\/script/)?.[1] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  try {
    const body = await readJsonBody(req);
    const shots = Array.isArray(body?.shots) ? body.shots.map((shot, index) => {
      const previous = project.shots.find((item) => item.id === shot.id) || {};
      const sourceFrame = previous.sourceFrame || project.frames[0] || null;
      return { ...previous, ...shot, id: String(shot.id || previous.id || `shot-${String(index + 1).padStart(2, "0")}`), order: index + 1, sourceFrame };
    }) : project.shots;
    const errors = validateVideoRemixDraft({ ...project, shots });
    if (errors.length) throw Object.assign(new Error(errors[0]), { statusCode: 400 });
    const resetGenerated = body?.resetGenerated === true;
    const changedShots = shots.map((shot) => {
      const previous = project.shots.find((item) => item.id === shot.id);
      const promptChanged = previous && ["startSeconds", "endSeconds", "sceneSummary", "imagePrompt", "videoPrompt"].some((key) => String(previous[key] ?? "") !== String(shot[key] ?? ""));
      if (resetGenerated) return { ...shot, imageStatus: "idle", imageTaskId: "", imageResultUrl: "", imageError: "", imageApprovedAt: null, videoStatus: "idle", videoTaskId: "", videoResultUrl: "", videoError: "" };
      return promptChanged ? invalidateShotAfterPromptEdit(shot) : shot;
    });
    const updated = videoRemixStore.replaceShots(id, changedShots);
    const patched = videoRemixStore.patch(id, { title: String(body?.title ?? project.title).trim().slice(0, 160), overallScript: String(body?.overallScript ?? project.overallScript).trim().slice(0, 10000), status: updated.status === "draft" ? "script_review" : updated.status, error: "" });
    sendJson(res, 200, { project: publicVideoRemixResult(patched) });
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "脚本保存失败。" });
  }
}

async function handleVideoRemixAnalyze(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/video-remixes\/([^/?]+)\/analyze/)?.[1] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  if (!project.sourceVideo) return sendJson(res, 400, { message: "请先上传源视频。" });
  if (project.status === "analyzing") return sendJson(res, 409, { message: "项目正在分析中，请稍候。" });
  void analyzeVideoRemixProject(id).catch((error) => console.warn("[video-remix] analysis failed", error instanceof Error ? error.message : error));
  sendJson(res, 202, { project: publicVideoRemixResult(videoRemixStore.patch(id, { status: "analyzing", error: "" })) });
}

async function handleVideoRemixConfirmScript(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/video-remixes\/([^/?]+)\/confirm-script/)?.[1] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  const errors = validateVideoRemixDraft(project);
  if (!project.sourceVideo) errors.push("请先上传源视频。");
  if (!project.productImages?.length) errors.push("请至少上传 1 张产品参考图。");
  if (errors.length) return sendJson(res, 400, { message: errors[0] });
  const updated = videoRemixStore.patch(id, { scriptConfirmedAt: new Date().toISOString(), status: "script_confirmed", error: "" });
  sendJson(res, 200, { project: publicVideoRemixResult(updated) });
}

async function handleVideoRemixStoryboardGenerate(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/video-remixes\/([^/]+)\/storyboards/)?.[1] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  if (!project.scriptConfirmedAt) return sendJson(res, 400, { message: "请先确认脚本和产品参考图。" });
  const queued = [];
  try {
    for (const shot of project.shots) {
      if (["queued", "running"].includes(shot.imageStatus) || shot.imageStatus === "approved") continue;
      queued.push(await queueVideoRemixStoryboardShot(videoRemixStore.get(id), shot, owner));
    }
    sendJson(res, 202, { project: publicVideoRemixResult(videoRemixStore.patch(id, { status: queued.length ? "running" : project.status, error: "" })), taskIds: queued.map((task) => task.id) });
  } catch (error) {
    videoRemixStore.failQueuedShots(id, error instanceof Error ? error.message : "分镜图任务创建失败。", "image");
    sendJson(res, Number(error?.statusCode || 502), { message: error instanceof Error ? error.message : "分镜图任务创建失败。" });
  }
}

async function handleVideoRemixImageRetry(req, res, owner) {
  const match = req.url.match(/^\/workbench\/video-remixes\/([^/]+)\/shots\/([^/]+)\/retry-image/);
  const id = decodeURIComponent(match?.[1] || "");
  const shotId = decodeURIComponent(match?.[2] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  const shot = project?.shots?.find((item) => item.id === shotId);
  if (!project || !shot) return sendJson(res, 404, { message: "视频再生镜头不存在。" });
  try {
    const task = await queueVideoRemixStoryboardShot(project, shot, owner);
    sendJson(res, 202, { project: publicVideoRemixResult(videoRemixStore.get(id)), taskId: task.id });
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 502), { message: error instanceof Error ? error.message : "镜头重生成失败。" });
  }
}

function handleVideoRemixImageApprove(req, res, owner) {
  const match = req.url.match(/^\/workbench\/video-remixes\/([^/]+)\/shots\/([^/]+)\/approve-image/);
  const id = decodeURIComponent(match?.[1] || "");
  const shotId = decodeURIComponent(match?.[2] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  const shot = project?.shots?.find((item) => item.id === shotId);
  if (!project || !shot) return sendJson(res, 404, { message: "视频再生镜头不存在。" });
  if (shot.imageStatus !== "ready" || !shot.imageResultUrl) return sendJson(res, 400, { message: "该镜头还没有可确认的分镜图。" });
  const updated = videoRemixStore.patchShot(id, shotId, { imageStatus: "approved", imageApprovedAt: new Date().toISOString(), imageError: "" });
  sendJson(res, 200, { project: publicVideoRemixResult(updated) });
}

async function handleVideoRemixVideoGenerate(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/video-remixes\/([^/]+)\/videos/)?.[1] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  if (!allStoryboardShotsApproved(project.shots)) return sendJson(res, 400, { message: "请先确认全部分镜图。" });
  const queued = [];
  try {
    for (const shot of project.shots) {
      if (["queued", "running", "done"].includes(shot.videoStatus)) continue;
      queued.push(await queueVideoRemixVideoShot(videoRemixStore.get(id), shot, owner));
    }
    sendJson(res, 202, { project: publicVideoRemixResult(videoRemixStore.patch(id, { status: queued.length ? "running" : project.status, error: "" })), taskIds: queued.map((task) => task.id) });
  } catch (error) {
    videoRemixStore.failQueuedShots(id, error instanceof Error ? error.message : "视频任务创建失败。", "video");
    sendJson(res, Number(error?.statusCode || 502), { message: error instanceof Error ? error.message : "视频任务创建失败。" });
  }
}

async function handleVideoRemixVideoRetry(req, res, owner) {
  const match = req.url.match(/^\/workbench\/video-remixes\/([^/]+)\/shots\/([^/]+)\/retry-video/);
  const id = decodeURIComponent(match?.[1] || "");
  const shotId = decodeURIComponent(match?.[2] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  const shot = project?.shots?.find((item) => item.id === shotId);
  if (!project || !shot) return sendJson(res, 404, { message: "视频再生镜头不存在。" });
  if (shot.imageStatus !== "approved") return sendJson(res, 400, { message: "请先确认该镜头的分镜图。" });
  try {
    const task = await queueVideoRemixVideoShot(project, shot, owner);
    sendJson(res, 202, { project: publicVideoRemixResult(videoRemixStore.get(id)), taskId: task.id });
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 502), { message: error instanceof Error ? error.message : "视频重生成失败。" });
  }
}

function handleVideoRemixMedia(req, res, owner) {
  const match = req.url.match(/^\/workbench\/video-remixes\/([^/]+)\/media\/([^/?]+)/);
  const id = decodeURIComponent(match?.[1] || "");
  const mediaId = decodeURIComponent(match?.[2] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  const media = mediaId === "source-video"
    ? project.sourceVideo
    : project.frames.find((item) => item.mediaId === mediaId) || project.productImages.find((item) => item.mediaId === mediaId);
  if (!media?.stagedPath) return sendJson(res, 404, { message: "项目媒体不存在。" });
  try {
    const path = resolveProjectMediaPath(id, media.stagedPath, { root: videoRemixMediaRoot });
    const stats = statSync(path);
    res.writeHead(200, { "content-type": media.mimeType || "application/octet-stream", "content-length": stats.size, "cache-control": "private, max-age=300" });
    createReadStream(path).pipe(res);
  } catch {
    sendJson(res, 404, { message: "项目媒体不存在。" });
  }
}

function handleVideoRemixDelete(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/video-remixes\/([^/?]+)/)?.[1] || "");
  const project = videoRemixProjectOrNotFound(id, owner);
  if (!project) return sendJson(res, 404, { message: "视频再生项目不存在。" });
  videoRemixStore.remove(id);
  for (const task of taskStore.list().filter((item) => item.remixProjectId === id)) taskStore.remove(task.id);
  void removeVideoRemixDirectory(id, { root: videoRemixMediaRoot }).catch((error) => console.warn("[video-remix] media cleanup failed", error instanceof Error ? error.message : error));
  sendJson(res, 200, { ok: true });
}

function claimVideoMedia(media, owner, taskIdentifier, uploadStore) {
  if (!media?.stagedUploadId) return media;
  const record = uploadStore.get(media.stagedUploadId);
  if (!record) throw Object.assign(new Error("视频或首尾帧上传不可用，请重新上传。"), { statusCode: 400 });
  return claimUpload(uploadStore, record, owner, taskIdentifier).media;
}

function claimVideoReferences(input, owner, taskIdentifier, uploadStore) {
  return {
    ...input,
    referenceImages: (input.referenceImages || []).map((media) => claimVideoMedia(media, owner, taskIdentifier, uploadStore)),
    ...(input.motionVideo ? { motionVideo: claimVideoMedia(input.motionVideo, owner, taskIdentifier, uploadStore) } : {}),
  };
}

async function createWorkbenchTask(input, owner, { uploadStore = stagedUploadStore } = {}) {
  const ownerInfo = ownerIdentity(owner);
  if (input?.kind === "video") {
    const normalized = { ...input, kind: "video" };
    const errors = validateVideoInput(normalized);
    if (errors.length) throw Object.assign(new Error(errors[0]), { statusCode: 400 });
    const id = taskId();
    const claimed = claimVideoReferences(normalized, ownerInfo, id, uploadStore);
    return createTaskAndUsage({ id, owner: ownerInfo, kind: "video", expectedPredictionCount: 1, status: "queued", input: claimed, results: [], error: "", predictionId: null, predictionIds: [] });
  }
  if (input?.mode === "product-cutout") {
    const normalized = normalizeCutoutInput(input);
    const images = Array.isArray(input.images) ? input.images : [];
    const errors = validateCutoutInput(normalized, images);
    if (errors.length) throw Object.assign(new Error(errors[0]), { statusCode: 400 });
    const id = taskId();
    const referencedUploads = images.filter((image) => image?.stagedUploadId);
    if (referencedUploads.length > 0 && referencedUploads.length !== images.length) {
      throw Object.assign(new Error("图片上传状态不一致，请重新上传后再试。"), { statusCode: 400 });
    }
    const stagedImages = referencedUploads.length > 0
      ? claimStagedUploadReferences(images, { owner: ownerInfo.username, accountId: ownerInfo.accountId, taskId: id, store: uploadStore })
      : stageImagesLocally(images, { taskId: id, root: stagedImagesRoot, maxBytes: maxImportedImageBytes });
    return createTaskAndUsage({
      id,
      owner: ownerInfo,
      kind: "image",
      expectedPredictionCount: 1,
      status: "queued",
      input: { ...normalized, mode: "product-cutout", provider: "bria", nanoModel: "bria-extract-object", images: stagedImages },
      results: [],
      error: "",
      predictionId: null,
      predictionIds: [],
    });
  }
  if (!input?.prompt?.trim()) throw Object.assign(new Error("请先输入提示词。"), { statusCode: 400 });
  normalizeRequestOptions(input);
  const id = taskId();
  const images = Array.isArray(input.images) ? input.images : [];
    if (isGrokImageRequest(input)) {
      const errors = validateGrokImageInput(input, images);
      if (errors.length) throw Object.assign(new Error(errors[0]), { statusCode: 400 });
    }
    if (isKlingImageRequest(input)) {
      const errors = validateKlingImageInput(input, images);
      if (errors.length) throw Object.assign(new Error(errors[0]), { statusCode: 400 });
    }
  validateReferenceImageCount(images, maxReferenceImages);
  const referencedUploads = images.filter((image) => image?.stagedUploadId);
  if (referencedUploads.length > 0 && referencedUploads.length !== images.length) {
    throw Object.assign(new Error("图片上传状态不一致，请重新上传后再试。"), { statusCode: 400 });
  }
  const stagedImages = referencedUploads.length > 0
    ? claimStagedUploadReferences(images, { owner: ownerInfo.username, accountId: ownerInfo.accountId, taskId: id, store: uploadStore })
    : stageImagesLocally(images, { taskId: id, root: stagedImagesRoot, maxBytes: maxImportedImageBytes });
  return createTaskAndUsage({ id, owner: ownerInfo, kind: "image", expectedPredictionCount: isGrokImageRequest(input) || isKlingImageRequest(input) || isEditMultiRequest(input) ? 1 : Math.max(1, Math.min(8, Number(input.count) || 1)), status: "queued", input: { ...input, kind: "image", images: stagedImages }, results: [], error: "", predictionId: null, predictionIds: [] });
}

async function handleTasksCreate(req, res, owner, videoOnly = false) {
  try {
    const input = await readJsonBody(req);
    if (videoOnly && input?.kind !== "video") throw Object.assign(new Error("该接口只接受视频任务。"), { statusCode: 400 });
    const task = await createWorkbenchTask(input, owner);
    taskScheduler.enqueue(task);
    sendJson(res, 201, { task: publicTask(task) });
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 502), { message: error instanceof Error ? error.message : "无法创建任务。" });
  }
}

function handleTasksList(res, owner) {
  sendJson(res, 200, { tasks: taskStore.list().filter((task) => !task.suiteId && task.kind !== "suite" && (task.accountId ? task.accountId === owner.accountId : task.owner === owner.username)).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).map(publicTask) });
}

function ownsTask(task, owner) {
  return Boolean(task && (task.accountId ? task.accountId === owner.accountId : task.owner === owner.username));
}

function handleTaskRetry(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/tasks\/([^/]+)\/retry/)?.[1] || "");
  const task = taskStore.get(id);
  if (task && !ownsTask(task, owner)) return sendJson(res, 404, { message: "Task not found." });
  if (!task || task.owner !== owner.username) return sendJson(res, 404, { message: "任务不存在。" });
  const retry = createTaskAndUsage({ id: taskId(), owner, kind: task.kind, expectedPredictionCount: task.expectedPredictionCount || (task.kind === "video" ? 1 : Math.max(1, Math.min(8, Number(task.input?.count) || 1))), status: "queued", input: task.input, results: [], error: "", predictionId: null, predictionIds: [], retryOf: task.id });
  taskScheduler.enqueue(retry);
  sendJson(res, 201, { task: publicTask(retry) });
}

function handleTaskCancel(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/tasks\/([^/]+)\/cancel/)?.[1] || "");
  const task = taskStore.get(id);
  if (task && !ownsTask(task, owner)) return sendJson(res, 404, { message: "Task not found." });
  if (!task || task.owner !== owner.username) return sendJson(res, 404, { message: "任务不存在。" });
  const status = task.status === "queued" ? "cancelled" : "cancel_requested";
  sendJson(res, 200, { task: publicTask(patchTaskAndUsage(id, { status, cancelledAt: new Date().toISOString() }, true)) });
}

function requireUser(req, res) {
  const user = currentUser(req);
  if (!user) {
    sendJson(res, 401, { message: "Please sign in to continue." });
    return null;
  }
  return user;
}

function requireAdmin(req, res) {
  const user = requireUser(req, res);
  if (!user) return null;
  if (user.role !== "admin") {
    sendJson(res, 403, { message: "Administrator access is required." });
    return null;
  }
  return user;
}

async function handleLogin(req, res) {
  try {
    if (!sessionSecret()) {
      sendJson(res, 503, { message: "Authentication is not configured yet." });
      return;
    }
    const body = await readJsonBody(req);
    const username = String(body?.username || "").trim();
    const password = String(body?.password || "");
    const store = usersStore();
    const user = store.users.find((item) => item.username === username);
    if (!user || !passwordMatches(password, user.passwordHash)) {
      sendJson(res, 401, { message: "Invalid username or password." });
      return;
    }
    user.lastLoginAt = new Date().toISOString();
    writeUsersStore(store);
    const session = sessionForUser(user);
    sendJson(res, 200, { user: publicUser(user) }, { "set-cookie": cookieForSession(session, req) });
  } catch {
    sendJson(res, 400, { message: "Unable to sign in." });
  }
}

function handleCurrentUser(req, res) {
  const user = requireUser(req, res);
  if (user) sendJson(res, 200, { user: publicUser(user) });
}

function handleLogout(req, res) {
  sendJson(res, 200, { ok: true }, { "set-cookie": clearSessionCookie(req) });
}

function handleUsersList(req, res) {
  if (!requireAdmin(req, res)) return;
  sendJson(res, 200, { users: usersStore().users.map(publicUser) });
}

async function handleCreateUser(req, res) {
  if (!requireAdmin(req, res)) return;
  try {
    const body = await readJsonBody(req);
    const username = String(body?.username || "").trim();
    const password = String(body?.password || "");
    const role = body?.role === "admin" ? "admin" : "user";
    if (!/^[A-Za-z0-9_.-]{3,48}$/.test(username)) {
      sendJson(res, 400, { message: "Username must be 3-48 characters using letters, numbers, dot, dash, or underscore." });
      return;
    }
    if (password.length < 10) {
      sendJson(res, 400, { message: "Password must be at least 10 characters." });
      return;
    }
    const store = usersStore();
    if (store.users.some((item) => item.username.toLowerCase() === username.toLowerCase())) {
      sendJson(res, 409, { message: "That username already exists." });
      return;
    }
    const user = { username, accountId: randomBytes(16).toString("hex"), passwordHash: hashPassword(password), role, createdAt: new Date().toISOString(), lastLoginAt: null };
    store.users.push(user);
    writeUsersStore(store);
    sendJson(res, 201, { user: publicUser(user) });
  } catch {
    sendJson(res, 400, { message: "Unable to create user." });
  }
}

function handleDeleteUser(req, res) {
  const actor = requireAdmin(req, res);
  if (!actor) return;
  const match = req.url.match(/^\/admin\/users\/([^/?]+)/);
  const username = match ? decodeURIComponent(match[1]) : "";
  const store = usersStore();
  const target = store.users.find((item) => item.username === username);
  if (!target) {
    sendJson(res, 404, { message: "User not found." });
    return;
  }
  if (target.username === actor.username) {
    sendJson(res, 400, { message: "You cannot delete your own account." });
    return;
  }
  if (target.role === "admin" && store.users.filter((item) => item.role === "admin").length <= 1) {
    sendJson(res, 400, { message: "At least one administrator must remain." });
    return;
  }
  store.users = store.users.filter((item) => item.username !== username);
  writeUsersStore(store);
  sendJson(res, 200, { ok: true });
}

function currentUsageSummary(range = null) {
  const sync = usageSynchronizer.status();
  return {
    ...summarizeUsage({
      trackingStartedAt: usageLedger.snapshot().trackingStartedAt,
      lastSyncedAt: usageLedger.snapshot().lastSyncedAt,
      pendingSyncCount: sync.pendingSyncCount,
      users: usersWithMcpService(mcpConfig, usersStore().users),
      entries: usageLedger.list(),
      range,
    }),
    sync,
  };
}

function handleUsageGet(req, res) {
  if (!requireAdmin(req, res)) return;
  try {
    const url = new URL(req.url, "http://localhost");
    const range = normalizeUsageRange({ from: url.searchParams.get("from"), to: url.searchParams.get("to"), groupBy: url.searchParams.get("groupBy") });
    sendJson(res, 200, usageResponse(currentUsageSummary(range)));
  } catch (error) {
    sendJson(res, 400, { message: error instanceof Error ? error.message : "时间范围无效。" });
  }
}

async function handleProductSuiteCreate(req, res, owner) {
  try {
    const input = await readJsonBody(req);
    const { suite, task } = createProductSuiteTask(input, owner);
    taskScheduler.enqueue(task);
    sendJson(res, 201, { suite: publicSuiteResult(suite) });
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "无法创建商品套图任务。" });
  }
}

async function handleProductSuiteRecoverBackground(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/product-suites\/([^/?]+)\/recover-background$/)?.[1] || "");
  const suite = productSuiteStore.get(id);
  if (!suite || !suiteOwnerMatches(suite, owner)) return sendJson(res, 404, { message: "商品套图任务不存在。" });
  const productUrl = suite.productImageUrl || cutoutResultUrlForSuite(id, taskStore.list());
  if (!canRecoverProductSuiteBackground(suite, productUrl)) {
    return sendJson(res, 409, { message: "当前套图没有可恢复的抠图结果，请重新创建套图任务。" });
  }

  const stagingId = taskId();
  try {
    const body = await readJsonBody(req);
    const backgroundImage = stageImagesLocally([body?.backgroundImage], {
      taskId: stagingId,
      root: stagedImagesRoot,
      maxBytes: maxImportedImageBytes,
    })[0];
    const updated = productSuiteStore.patch(id, {
      status: "queued",
      error: "",
      productImageUrl: productUrl,
      backgroundImage,
      backgroundUrl: "",
    });
    const task = taskStore.create({ id: taskId(), owner: owner.username, accountId: owner.accountId, kind: "suite", suiteId: id, status: "queued", results: [], error: "" });
    taskScheduler.enqueue(task);
    sendJson(res, 201, { suite: publicSuiteResult(updated) });
  } catch (error) {
    cleanupStagedImages(stagingId, { root: stagedImagesRoot });
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "背景补传失败。" });
  }
}

function handleProductSuiteList(res, owner) {
  sendJson(res, 200, { suites: productSuiteStore.forOwner(owner).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).map(publicSuiteResult) });
}

function handleProductSuiteGet(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/product-suites\/([^/?]+)$/)?.[1] || "");
  const suite = productSuiteStore.get(id);
  if (!suite || !suiteOwnerMatches(suite, owner)) return sendJson(res, 404, { message: "Product suite not found." });
  sendJson(res, 200, { suite: publicSuiteResult(suite) });
}

async function handleProductSuitePatch(req, res, owner) {
  try {
    const id = decodeURIComponent(req.url.match(/^\/workbench\/product-suites\/([^/?]+)$/)?.[1] || "");
    const suite = productSuiteStore.get(id);
    if (!suite || !suiteOwnerMatches(suite, owner)) return sendJson(res, 404, { message: "Product suite not found." });
    const body = await readJsonBody(req);
    const prompts = body?.prompts && typeof body.prompts === "object" ? body.prompts : {};
    const allowed = new Set(PRODUCT_SUITE_SLOTS.map((slot) => slot.slot));
    const items = suite.items.map((item) => allowed.has(item.slot) && typeof prompts[item.slot] === "string" ? { ...item, prompt: prompts[item.slot].trim().slice(0, 4000) } : item);
    const updated = productSuiteStore.patch(id, { items, input: { ...suite.input, prompts: Object.fromEntries(items.map((item) => [item.slot, item.prompt])) } });
    sendJson(res, 200, { suite: publicSuiteResult(updated) });
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "Unable to update product suite." });
  }
}

function handleProductSuiteRetry(req, res, owner) {
  const match = req.url.match(/^\/workbench\/product-suites\/([^/]+)\/retry\/([^/?]+)/);
  const id = decodeURIComponent(match?.[1] || "");
  const slot = decodeURIComponent(match?.[2] || "");
  const suite = productSuiteStore.get(id);
  if (!suite || !suiteOwnerMatches(suite, owner)) return sendJson(res, 404, { message: "商品套图任务不存在。" });
  if (!PRODUCT_SUITE_SLOTS.some((item) => item.slot === slot)) return sendJson(res, 400, { message: "无效的商品套图画面。" });
  const retrySlots = slot === "model-front" ? ["model-front", "model-angle", "model-back"] : [slot];
  for (const retrySlot of retrySlots) productSuiteStore.patchItem(id, retrySlot, { status: "queued", resultUrl: "", error: "" });
  if (slot === "model-front" && suite.modelReferenceImage) {
    productSuiteStore.patch(id, { modelReferenceAnalysis: null, modelReferenceAnalysisStatus: "queued", modelReferenceAnalysisUsage: null, input: { ...suite.input, modelReferenceAnalysis: null } });
  }
  const task = taskStore.create({ id: taskId(), owner: owner.username, accountId: owner.accountId, kind: "suite", suiteId: id, suiteRetrySlot: slot, status: "queued", results: [], error: "" });
  productSuiteStore.patch(id, { status: "queued" });
  taskScheduler.enqueue(task);
  sendJson(res, 201, { suite: publicSuiteResult(productSuiteStore.get(id)) });
}

async function handleProductSuiteDownload(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/product-suites\/([^/]+)\/download\.zip/)?.[1] || "");
  const suite = productSuiteStore.get(id);
  if (!suite || !suiteOwnerMatches(suite, owner)) return sendJson(res, 404, { message: "商品套图任务不存在。" });
  const entries = PRODUCT_SUITE_SLOTS.map((slot) => ({ name: slot.fileName, url: suite.items.find((item) => item.slot === slot.slot)?.resultUrl })).filter((entry) => entry.url);
  if (entries.length === 0) return sendJson(res, 409, { message: "还没有可下载的套图结果。" });
  try {
    const archive = await createZipArchive(entries);
    res.writeHead(200, { "content-type": "application/zip", "content-disposition": `attachment; filename="product-detail-suite-${id}.zip"`, "content-length": archive.length });
    res.end(archive);
  } catch (error) {
    sendJson(res, 502, { message: error instanceof Error ? error.message : "套图下载失败。" });
  }
}

async function handleMcpUploadPut(req, res) {
  const owner = authenticateMcpRequest(req.headers, mcpConfig);
  if (!owner) {
    sendJson(res, 401, { message: "MCP authorization required." });
    return;
  }
  const id = decodeURIComponent(req.url.match(/^\/mcp\/uploads\/([^/?]+)/)?.[1] || "");
  const record = mcpUploadStore.get(id);
  const uploadToken = Array.isArray(req.headers["x-upload-token"]) ? req.headers["x-upload-token"][0] : req.headers["x-upload-token"];
  const contentType = String(req.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
  if (!record || record.accountId !== owner.accountId || record.owner !== owner.username || record.status !== "pending" || Date.parse(record.expiresAt || "") <= Date.now() || !uploadTokenMatches(record, uploadToken) || (contentType && contentType !== record.mimeType)) {
    sendJson(res, 404, { message: "上传票据不存在、已过期或不可用。" });
    return;
  }
  try {
    await writeUploadBody(req, record, { root: mcpUploadsRoot });
    const ready = markUploadReady(mcpUploadStore, record, { root: mcpUploadsRoot });
    sendJson(res, 201, { upload: publicUpload(ready, owner) });
  } catch (error) {
    sendJson(res, Number(error?.statusCode || 400), { message: error instanceof Error ? error.message : "媒体上传失败。" });
  }
}

async function handleMcpDownload(req, res) {
  const owner = authenticateMcpRequest(req.headers, mcpConfig);
  if (!owner) {
    sendJson(res, 401, { message: "MCP authorization required." });
    return;
  }
  const match = req.url.match(/^\/mcp\/downloads\/(task|suite)\/([^/?]+)/);
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const claims = verifyDownloadToken(mcpConfig.token, url.searchParams.get("token"));
  if (!match || !claims || claims.accountId !== owner.accountId || claims.kind !== match[1] || claims.id !== decodeURIComponent(match[2])) {
    sendJson(res, 404, { message: "下载地址不存在或已过期。" });
    return;
  }
  if (claims.kind === "suite") {
    const suite = productSuiteStore.get(claims.id);
    if (!suite || !suiteOwnerMatches(suite, owner)) return sendJson(res, 404, { message: "商品套图任务不存在。" });
    const entries = PRODUCT_SUITE_SLOTS.map((slot) => ({ name: slot.fileName, url: suite.items.find((item) => item.slot === slot.slot)?.resultUrl })).filter((entry) => entry.url);
    if (!entries.length) return sendJson(res, 409, { message: "还没有可下载的套图结果。" });
    try {
      const archive = await createZipArchive(entries);
      res.writeHead(200, { "content-type": "application/zip", "content-disposition": `attachment; filename="product-detail-suite-${suite.id}.zip"`, "content-length": archive.length });
      res.end(archive);
    } catch (error) {
      sendJson(res, 502, { message: error instanceof Error ? error.message : "套图下载失败。" });
    }
    return;
  }
  const task = taskStore.get(claims.id);
  if (!task || !ownsTask(task, owner)) return sendJson(res, 404, { message: "任务不存在。" });
  const urls = (task.results || []).map((result) => result.url).filter(Boolean);
  if (!urls.length) return sendJson(res, 409, { message: "还没有可下载的任务结果。" });
  if (urls.length === 1) {
    res.writeHead(302, { location: urls[0], "cache-control": "private, max-age=60" });
    res.end();
    return;
  }
  try {
    const archive = await createZipArchive(urls.map((url, index) => ({ name: `result-${index + 1}.png`, url })));
    res.writeHead(200, { "content-type": "application/zip", "content-disposition": `attachment; filename="task-${task.id}.zip"`, "content-length": archive.length });
    res.end(archive);
  } catch (error) {
    sendJson(res, 502, { message: error instanceof Error ? error.message : "任务下载失败。" });
  }
}

function handleProductSuiteDelete(req, res, owner) {
  const id = decodeURIComponent(req.url.match(/^\/workbench\/product-suites\/([^/?]+)/)?.[1] || "");
  const suite = productSuiteStore.get(id);
  if (!suite || !suiteOwnerMatches(suite, owner)) return sendJson(res, 404, { message: "商品套图任务不存在。" });
  productSuiteStore.remove(id);
  for (const task of taskStore.list().filter((item) => item.suiteId === id)) taskStore.remove(task.id);
  cleanupStagedMediaReferences([...(Array.isArray(suite.sourceImages) ? suite.sourceImages : [suite.sourceImage]), suite.backgroundImage, suite.modelReferenceImage]);
  sendJson(res, 200, { ok: true });
}

function handleUsageSync(req, res) {
  if (!requireAdmin(req, res)) return;
  void usageSynchronizer.sync({ force: true }).catch(() => undefined);
  sendJson(res, 202, { accepted: true, sync: usageSynchronizer.status() });
}

function serveStatic(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const requested = decodeURIComponent(url.pathname);
  const safePath = normalize(requested).replace(/^(\.\.[/\\])+/, "");
  let filePath = join(root, safePath);

  if (!filePath.startsWith(root)) {
    sendText(res, 403, "Forbidden");
    return;
  }

  if (existsSync(filePath) && statSync(filePath).isDirectory()) {
    filePath = join(filePath, "index.html");
  }

  if (!existsSync(filePath)) {
    filePath = join(root, "index.html");
  }

  if (!existsSync(filePath)) {
    sendText(res, 500, "dist/index.html not found. Run npm run build first.");
    return;
  }

  const ext = extname(filePath).toLowerCase();
  res.writeHead(200, {
    "content-type": mimeTypes[ext] || "application/octet-stream",
  });
  createReadStream(filePath).pipe(res);
}

const httpServer = createServer((req, res) => {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
      "access-control-allow-headers": "authorization,content-type,x-upload-token",
    });
    res.end();
    return;
  }

  if (req.url === "/mcp" && ["GET", "POST", "DELETE"].includes(req.method)) {
    void handleMcpHttpRequest(req, res, {
      config: mcpConfig,
      createServer: (owner) => createMcpServer({ operations: createMcpOperationsFor(owner) }),
    });
    return;
  }

  if (req.url?.match(/^\/mcp\/uploads\/[^/?]+$/) && req.method === "PUT") {
    void handleMcpUploadPut(req, res);
    return;
  }

  if (req.url?.match(/^\/mcp\/downloads\/(task|suite)\/[^/?]+/) && req.method === "GET") {
    void handleMcpDownload(req, res);
    return;
  }

  if (req.url?.startsWith("/auth/login") && req.method === "POST") {
    void handleLogin(req, res);
    return;
  }

  if (req.url?.startsWith("/auth/me") && req.method === "GET") {
    handleCurrentUser(req, res);
    return;
  }

  if (req.url?.startsWith("/auth/logout") && req.method === "POST") {
    handleLogout(req, res);
    return;
  }

  if (req.url?.startsWith("/admin/usage?") && req.method === "GET") {
    handleUsageGet(req, res);
    return;
  }

  if (req.url === "/admin/usage" && req.method === "GET") {
    handleUsageGet(req, res);
    return;
  }

  if (req.url === "/admin/usage/sync" && req.method === "POST") {
    handleUsageSync(req, res);
    return;
  }

  if (req.url?.startsWith("/admin/users") && req.method === "GET") {
    handleUsersList(req, res);
    return;
  }

  if (req.url === "/admin/users" && req.method === "POST") {
    void handleCreateUser(req, res);
    return;
  }

  if (req.url?.startsWith("/admin/users/") && req.method === "DELETE") {
    handleDeleteUser(req, res);
    return;
  }

  if (req.url?.startsWith("/wavespeed/generate") && req.method === "POST") {
    if (!requireUser(req, res)) return;
    void handleGenerate(req, res);
    return;
  }

  if (req.url?.startsWith("/wavespeed/import-image") && req.method === "POST") {
    if (!requireUser(req, res)) return;
    void handleImportImage(req, res);
    return;
  }

  if (req.url === "/wavespeed/upload-media" && req.method === "POST") {
    if (!requireUser(req, res)) return;
    void handleUploadMedia(req, res);
    return;
  }

  if (req.url === "/workbench/tasks" && req.method === "GET") {
    const user = requireUser(req, res);
    if (user) handleTasksList(res, user);
    return;
  }

  if (req.url === "/workbench/product-suites" && req.method === "GET") {
    const user = requireUser(req, res);
    if (user) handleProductSuiteList(res, user);
    return;
  }

  if (req.url === "/workbench/product-suites" && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleProductSuiteCreate(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/product-suites\/[^/?]+$/) && req.method === "GET") {
    const user = requireUser(req, res);
    if (user) handleProductSuiteGet(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/product-suites\/[^/?]+$/) && req.method === "PATCH") {
    const user = requireUser(req, res);
    if (user) void handleProductSuitePatch(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/product-suites\/[^/]+\/retry\/[^/?]+/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) handleProductSuiteRetry(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/product-suites\/[^/]+\/recover-background$/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleProductSuiteRecoverBackground(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/product-suites\/[^/]+\/download\.zip/) && req.method === "GET") {
    const user = requireUser(req, res);
    if (user) void handleProductSuiteDownload(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/product-suites\/[^/?]+/) && req.method === "DELETE") {
    const user = requireUser(req, res);
    if (user) handleProductSuiteDelete(req, res, user);
    return;
  }

  if (req.url === "/workbench/stage-image" && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleStageImage(req, res, user);
    return;
  }

  if (req.url === "/workbench/video-remixes" && req.method === "GET") {
    const user = requireUser(req, res);
    if (user) handleVideoRemixList(res, user);
    return;
  }

  if (req.url === "/workbench/video-remixes" && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixCreate(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/media\/[^/?]+/) && req.method === "GET") {
    const user = requireUser(req, res);
    if (user) handleVideoRemixMedia(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/source-video/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixSourceUpload(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/product-images/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixProductImage(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/script/) && req.method === "PATCH") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixScriptPatch(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/analyze/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixAnalyze(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/confirm-script/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixConfirmScript(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/storyboards/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixStoryboardGenerate(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/shots\/[^/]+\/retry-image/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixImageRetry(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/shots\/[^/]+\/approve-image/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) handleVideoRemixImageApprove(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/videos/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixVideoGenerate(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/]+\/shots\/[^/]+\/retry-video/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleVideoRemixVideoRetry(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/?]+$/) && req.method === "GET") {
    const user = requireUser(req, res);
    if (user) handleVideoRemixGet(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/video-remixes\/[^/?]+$/) && req.method === "DELETE") {
    const user = requireUser(req, res);
    if (user) handleVideoRemixDelete(req, res, user);
    return;
  }

  if (req.url === "/workbench/tasks" && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleTasksCreate(req, res, user);
    return;
  }

  if (req.url === "/wavespeed/video/generate" && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) void handleTasksCreate(req, res, user, true);
    return;
  }

  if (req.url?.match(/^\/workbench\/tasks\/[^/]+\/retry/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) handleTaskRetry(req, res, user);
    return;
  }

  if (req.url?.match(/^\/workbench\/tasks\/[^/]+\/cancel/) && req.method === "POST") {
    const user = requireUser(req, res);
    if (user) handleTaskCancel(req, res, user);
    return;
  }

  if (req.url?.startsWith("/wavespeed/predictions/") && req.method === "GET") {
    if (!requireUser(req, res)) return;
    void handlePredictionResult(req, res);
    return;
  }

  serveStatic(req, res);
});

httpServer.on("clientError", (error, socket) => {
  console.warn("Rejected malformed client request", { code: error.code || "unknown", bytesParsed: error.bytesParsed || 0 });
  socket.end("HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n");
});

httpServer.listen(port, "0.0.0.0", () => {
  console.log(`AI image workbench listening on http://0.0.0.0:${port}`);
});

for (const task of taskStore.list().filter((item) => !item.suiteId)) {
  const action = recoveryAction(task);
  if (action === "enqueue") {
    recordUsageTask(task);
    taskScheduler.enqueue(task);
  }
  if (action === "requeue") {
    const recovered = patchTaskAndUsage(task.id, { status: "queued", error: "" });
    if (recovered) taskScheduler.enqueue(recovered);
  }
  if (action === "cancel") patchTaskAndUsage(task.id, { status: "cancelled", cancelledAt: new Date().toISOString() }, true);
}

for (const task of taskStore.list().filter((item) => item.kind === "suite" && (item.status === "queued" || item.status === "running"))) {
  const recovered = task.status === "running" ? taskStore.patch(task.id, { status: "queued", error: "" }) : task;
  if (recovered) taskScheduler.enqueue(recovered);
}

if (usageLedger.pendingCount() > 0) usageSynchronizer.enqueue();
