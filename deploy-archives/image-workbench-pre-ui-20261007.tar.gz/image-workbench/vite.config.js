import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
    base: "./",
    plugins: [react()],
    server: {
        host: "0.0.0.0",
        allowedHosts: ["terminal.local"],
        proxy: {
            "/gemai/v1beta": {
                target: "https://api.gemai.cc/v1beta",
                changeOrigin: true,
                rewrite: function (path) { return path.replace(/^\/gemai\/v1beta/, ""); },
            },
            "/gemai/v1": {
                target: "https://api.gemai.cc/v1",
                changeOrigin: true,
                rewrite: function (path) { return path.replace(/^\/gemai\/v1/, ""); },
            },
        },
    },
});
